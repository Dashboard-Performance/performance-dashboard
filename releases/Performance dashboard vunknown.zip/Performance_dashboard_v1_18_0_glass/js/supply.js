/* Supply Chain (v1.9.0): Inventory Aging overview, SKU analysis, Action plan.
   All numbers are calculated from the dashboard data (stock, COGS, inbound, confirmed sales). */
(function () {
  "use strict";
  var C = window.TowerCore; if (!C) return;
  function $(id) { return document.getElementById(id); }
  var esc = C.esc;
  function moneyC(n) { try { return fmtMoneyCompactCell(n); } catch (e) { return money(n); } }
  function money(n) { try { return fmtMoneyCompact(n); } catch (e) { return "EGP " + Math.round(n || 0).toLocaleString(); } }
  function int(n) { return Math.round(+n || 0).toLocaleString(); }
  function pct(n, d) { return (+n || 0).toFixed(d == null ? 1 : d) + "%"; }
  function dfmt(s) { if (!s) return "—"; var d = new Date(s); return isNaN(d) ? String(s) : d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "2-digit" }); }

  var AGES = ["1. 0-2 Months", "2. 2-4 Months", "3. 4-6 Months", "4. 6-12 Months", "5. Unhealthy"];
  var AGE_LBL = { "1. 0-2 Months": "0–2 months", "2. 2-4 Months": "2–4 months", "3. 4-6 Months": "4–6 months", "4. 6-12 Months": "6–12 months", "5. Unhealthy": "Unhealthy (12m+)" };
  var AGE_COL = ["#34d399", "#7dd3a8", "#fbbf24", "#fb923c", "#fb7185"];
  var CATS = ["electronics", "home", "consumables", "leisure", "fashion"];
  var CATL = { electronics: "Electronics", home: "Home", consumables: "Consumables", leisure: "Leisure", fashion: "Fashion", "taager gomla": "Taager Gomla", general: "General" };
  var TAGS = ["5- Overstocked", "4- Fairly Stocked", "3- Understocked", "2- At Risk", "1- OSS"];
  var FMS = ["1. Fast-Moving", "2. Medium-Moving", "3. Slow-Moving", "4. Obsolete"];
  var TAG_TONE = { "5- Overstocked": "bad", "4- Fairly Stocked": "ok", "3- Understocked": "warn", "2- At Risk": "warn", "1- OSS": "na" };
  var ACTIONS = ["Liquidation (On-Cost)", "Merchant Focus", "Telesales - Upselling - Cross Selling", "Supplier Returns"];
  // Proposed action = Lookups sheet: ABC_FMS_Quarter(of last purchase date) -> [action, channel] (first match)
  var ACT_LOOKUP = {"A_1. Fast-Moving_Q1": ["Merchant Focus", "Online"], "A_1. Fast-Moving_Q2": ["Merchant Focus", "Online"], "A_1. Fast-Moving_Q3": ["Merchant Focus", "Online"], "A_1. Fast-Moving_Before 2026": ["Merchant Focus", "Online"], "A_2. Medium-Moving_Q1": ["Merchant Focus", "Online"], "A_2. Medium-Moving_Q2": ["Merchant Focus", "Online"], "A_2. Medium-Moving_Q3": ["Merchant Focus", "Online"], "A_2. Medium-Moving_Before 2026": ["Merchant Focus", "Online"], "A_3. Slow-Moving_Q1": ["Supplier Returns", "Supply Team"], "A_3. Slow-Moving_Q2": ["Merchant Focus", "Online"], "A_3. Slow-Moving_Q3": ["Telesales - Upselling - Cross Selling", "Online"], "A_3. Slow-Moving_Before 2026": ["Liquidation (On-Cost)", "Offline - B2B"], "A_4. Obsolete_Q1": ["Supplier Returns", "Supply Team"], "A_4. Obsolete_Q2": ["Merchant Focus", "Online"], "A_4. Obsolete_Q3": ["Telesales - Upselling - Cross Selling", "Online"], "A_4. Obsolete_Before 2026": ["Liquidation (On-Cost)", "Offline - B2B"], "B_1. Fast-Moving_Q1": ["Merchant Focus", "Online"], "B_1. Fast-Moving_Q2": ["Merchant Focus", "Online"], "B_1. Fast-Moving_Q3": ["Merchant Focus", "Online"], "B_1. Fast-Moving_Before 2026": ["Merchant Focus", "Online"], "B_2. Medium-Moving_Q1": ["Merchant Focus", "Online"], "B_2. Medium-Moving_Q2": ["Merchant Focus", "Online"], "B_2. Medium-Moving_Q3": ["Merchant Focus", "Online"], "B_2. Medium-Moving_Before 2026": ["Merchant Focus", "Online"], "B_3. Slow-Moving_Q1": ["Supplier Returns", "Supply Team"], "B_3. Slow-Moving_Q2": ["Merchant Focus", "Online"], "B_3. Slow-Moving_Q3": ["Telesales - Upselling - Cross Selling", "Online"], "B_3. Slow-Moving_Before 2026": ["Liquidation (On-Cost)", "Offline - B2B"], "B_4. Obsolete_Q1": ["Supplier Returns", "Supply Team"], "B_4. Obsolete_Q2": ["Merchant Focus", "Online"], "B_4. Obsolete_Q3": ["Telesales - Upselling - Cross Selling", "Online"], "B_4. Obsolete_Before 2026": ["Liquidation (On-Cost)", "Offline - B2B"], "C_1. Fast-Moving_Q1": ["Merchant Focus", "Online"], "C_1. Fast-Moving_Q2": ["Merchant Focus", "Online"], "C_1. Fast-Moving_Q3": ["Merchant Focus", "Online"], "C_1. Fast-Moving_Before 2026": ["Merchant Focus", "Online"], "C_2. Medium-Moving_Q1": ["Merchant Focus", "Online"], "C_2. Medium-Moving_Q2": ["Merchant Focus", "Online"], "C_2. Medium-Moving_Q3": ["Merchant Focus", "Online"], "C_2. Medium-Moving_Before 2026": ["Merchant Focus", "Online"], "C_3. Slow-Moving_Q1": ["Supplier Returns", "Supply Team"], "C_3. Slow-Moving_Q2": ["Merchant Focus", "Online"], "C_3. Slow-Moving_Q3": ["Telesales - Upselling - Cross Selling", "Online"], "C_3. Slow-Moving_Before 2026": ["Liquidation (On-Cost)", "Offline - B2B"], "C_4. Obsolete_Q1": ["Supplier Returns", "Supply Team"], "C_4. Obsolete_Q2": ["Merchant Focus", "Online"], "C_4. Obsolete_Q3": ["Telesales - Upselling - Cross Selling", "Online"], "C_4. Obsolete_Before 2026": ["Liquidation (On-Cost)", "Offline - B2B"]};
  var ACT_NOTE = { "Liquidation (On-Cost)": "Offline - B2B", "Merchant Focus": "Online", "Telesales - Upselling - Cross Selling": "Online", "Supplier Returns": "Supply Team" };

  /* ---------------------------------------------------------------- data (computed from the dashboard's own data) */
  var SC = { rows: [], asOf: "", sig: "", cat: "all", sk: { q: "", cat: "", aging: "", tag: "", seg: "", action: "", repack: "", instock: true, key: "inv", dir: "desc", page: 0 }, act: ACTIONS[0], empty: true, segMode: "segA" };
  var PAGE = 25, DAY = 86400000;
  // v1.17.0 — ACTUAL returns (warehouse scans "Product is good", Return_Archive_YYYY-MM → Return_RCV) — used ONLY in the
  // Supply conversion → Returns row below. Nothing else in the dashboard uses it.
  var RET = { month: "", data: null, loading: false, err: "" };
  function loadActualReturns(month) {
    if (RET.loading || (RET.month === month && (RET.data || RET.err))) return;
    RET.loading = true; RET.month = month;
    C.wfetch("actualReturns", { timeout: 120000 }, "&month=" + encodeURIComponent(month)).then(function (j) {
      if (!j || j.success === false) throw new Error((j && j.message) || "failed");
      RET.data = j; RET.err = "";
    }).catch(function (e) { RET.data = null; RET.err = (e && e.message) || "failed"; })
      .then(function () { RET.loading = false; SC.sig = ""; rerender(); });
  }
  function sigNow() { try { return [($("monthSelect") || {}).value || "", state.allParsedRows.length, (state.productOnlyRows || []).length, typeof productMode === "function" ? productMode() : "", (state.inboundRows || []).length, Object.keys(state.inventoryMap || {}).length, state.cogsMap && state.cogsMap.size, (state.debundleMap || []).length, (state.supplyRepackRows || []).length, (state.metabaseSellthroughNeeded || []).length, (state.metabaseBeginningInventory || []).length, impPosSig()].join("|"); } catch (e) { return ""; } }
  // v1.17.0 — the Importation PO list is part of the signature so the table rebuilds when the saved plan arrives or changes
  function impPosSig() { try { var P = window.TaagerPlans; if (!P) return ""; var k = planKey(), h = P.peek("supplyplan", k); var v = h ? h.values : P.SUPPLY_DEF; return String(v.impPos || "") + "~" + String(v.exclEnds || ""); } catch (e) { return ""; } }
  function ageIdx(days) { return days == null ? 4 : days <= 60 ? 0 : days <= 120 ? 1 : days <= 180 ? 2 : days <= 364 ? 3 : 4; } // same bands as the Inventory Aging sheet; no purchase date = Unhealthy
  var RET_FACTOR = 0.75; // Returns = MAX(0, Confirmed − Delivered) × 75% (conservative haircut, same as the Purchase Plan sheet)
  var SEGS = ["Mega", "Super", "Winning", "Potential Winning", "Normal"], SEG_MIN = [1200000, 400000, 200000, 100000, 0];
  function segOf(g) { for (var i = 0; i < 4; i++) if (g >= SEG_MIN[i]) return SEGS[i]; return SEGS[4]; }
  function build() {
    var sg = sigNow(); if (sg && sg === SC.sig) return; SC.sig = sg;
    var rows = [];
    try {
      var main = (typeof productLevelRows === "function" ? productLevelRows() : (state.allParsedRows || [])), invMap = state.inventoryMap || {};
      if (!main.length || !Object.keys(invMap).length || typeof buildDebundledStockDohIndex !== "function") { SC.rows = []; SC.empty = true; return; }
      var idx = buildDebundledStockDohIndex(main), dbm = buildDebundleProductMap(state.debundleMap, state.cogsMap), pm = dbm.productMap, singles = dbm.singlesList;
      var mapsFor = function (sku) { var m = pm.get(sku); return (m && m.length) ? m : [{ singleId: sku, quantity: 1 }]; };
      var t0 = new Date(); t0.setHours(0, 0, 0, 0); var today = t0.getTime();
      var maxTs = 0; main.forEach(function (r) { if (r.timestamp > maxTs) maxTs = r.timestamp; });
      var ref = new Date(maxTs || today), cy = ref.getFullYear(), cmo = ref.getMonth(), elapsed = ref.getDate() || 1, mdays = new Date(cy, cmo + 1, 0).getDate();
      var py = cmo === 0 ? cy - 1 : cy, pmo = cmo === 0 ? 11 : cmo - 1;
      // v1.18.0 — Supply conversion follows the month filter at the top (Overall = the latest month with data, as before).
      // A past month is rebuilt from its own rows / receipts / repack / returns / Beginning Inventory and read against its own plan.
      // The rest of this page (stock, aging, DOH) stays on the latest data — it is stock as of now.
      var ccy = cy, ccmo = cmo, cref = ref, celapsed = elapsed, cmdays = mdays;
      (function () {
        var v = ($("monthSelect") || {}).value || "", d = v ? new Date("1 " + v) : null;
        if (!d || isNaN(d.getTime()) || (d.getFullYear() === cy && d.getMonth() === cmo)) return;
        ccy = d.getFullYear(); ccmo = d.getMonth(); cmdays = new Date(ccy, ccmo + 1, 0).getDate();
        var mx = 0; main.forEach(function (r) { var t = new Date(r.timestamp); if (t.getFullYear() === ccy && t.getMonth() === ccmo && r.timestamp > mx) mx = r.timestamp; });
        cref = mx ? new Date(mx) : new Date(ccy, ccmo, 1); celapsed = mx ? cref.getDate() : 0;
      })();
      var convSame = ccy === cy && ccmo === cmo;
      SC.convKey = ccy + "-" + String(ccmo + 1).padStart(2, "0"); // the plan (Planned, Importation POs, packaging) is read for this month
      var c3 = {}, c15 = {}, c30 = {}, gA = {}, gL = {}, mtd = {}, dP = {}, dG = {}, dMtd = {};
      main.forEach(function (r) {
        if (!r.sku) return;
        var d = new Date(r.timestamp), dd = new Date(r.timestamp); dd.setHours(0, 0, 0, 0); var age = Math.round((today - dd.getTime()) / DAY); // whole days (an hour off in the week the clock changes)
        var inCur = d.getFullYear() === cy && d.getMonth() === cmo, inPrev = d.getFullYear() === py && d.getMonth() === pmo;
        var needQ = r.confirmedPieces && ((age >= 1 && age <= 30) || inCur), needG = (inCur || inPrev) && r.confirmedGmv;
        // v1.17.0 — Delivered ASP (last 30 full days): delivered GMV ÷ delivered pieces, bundles split to their singles
        if (r.deliveredPieces > 0 && age >= 1 && age <= 30) mapsFor(r.sku).forEach(function (mp) { var id = mp.singleId; dP[id] = (dP[id] || 0) + r.deliveredPieces * (mp.quantity || 1); dG[id] = (dG[id] || 0) + (r.deliveredGmv || 0) * (mp.cogsWeight != null ? mp.cogsWeight : 1); });
        // v1.17.0 — delivered pieces for THIS month, for Delivered COGS. dP above is a rolling 30 days (ASP), not the month.
        if (r.deliveredPieces > 0 && inCur) mapsFor(r.sku).forEach(function (mp) { dMtd[mp.singleId] = (dMtd[mp.singleId] || 0) + r.deliveredPieces * (mp.quantity || 1); });
        if (!needQ && !needG) return;
        mapsFor(r.sku).forEach(function (mp) {
          var id = mp.singleId;
          if (needQ) { var q = r.confirmedPieces * (mp.quantity || 1); if (inCur) mtd[id] = (mtd[id] || 0) + q; if (age < 1 || age > 30) { /* only MTD */ } else { if (age <= 3) c3[id] = (c3[id] || 0) + q; if (age <= 15) c15[id] = (c15[id] || 0) + q; c30[id] = (c30[id] || 0) + q; } }
          if (needG) { var g = r.confirmedGmv * (mp.cogsWeight != null ? mp.cogsWeight : 1); if (inCur) gA[id] = (gA[id] || 0) + g; else gL[id] = (gL[id] || 0) + g; }
        });
      });
      // v1.17.0 — Importation = the pieces RECEIVED under an Importation PO (Odoo_NO in the Inbound sheet).
      // The PO list is edited in Control -> Targets -> Supply conversion plan.
      var impPo = {}, impSku = {}, impPoOf = {}, impM = {}, impLines = 0;
      (window.TaagerPlans ? window.TaagerPlans.parsePos(planGet().impPos) : []).forEach(function (x) { impPo[x] = 1; });
      var isImpPo = function (r) { var po = String(r.po || "").trim().toUpperCase(); return !!(po && impPo[po]); };
      if (Object.keys(impPo).length) (state.inboundRows || []).forEach(function (r) {
        if (!r.sku || !isImpPo(r)) return;
        impSku[r.sku] = 1; if (!impPoOf[r.sku]) impPoOf[r.sku] = String(r.po).trim().toUpperCase(); impLines++;
      });
      SC.impPo = Object.keys(impPo); SC.impSkuN = Object.keys(impSku).length; SC.impLines = impLines;

      // v1.17.0 — packaging SKUs (cartons/boxes) are not product: anything whose ID ends with one of these
      // is left out of Supply conversion. Edited in Control -> Targets -> Supply conversion plan.
      var exclEnds = (window.TaagerPlans ? window.TaagerPlans.parsePos(planGet().exclEnds) : []);
      var isExcluded = function (id) {
        var u = String(id || "").toUpperCase();
        for (var i = 0; i < exclEnds.length; i++) if (u.length > exclEnds[i].length && u.slice(-exclEnds[i].length) === exclEnds[i]) return true;
        return false;
      };
      SC.exclEnds = exclEnds; SC.exclN = 0;

      var beg = {}, inM = {};
      (state.metabaseBeginningInventory || []).forEach(function (r) { var d = new Date(r.MONTH); if (isNaN(d.getTime()) || d.getUTCFullYear() !== cy || d.getUTCMonth() !== cmo) return; beg[r.PRODUCT_ID] = (beg[r.PRODUCT_ID] || 0) + (+r.QTY || 0); });
      // this month's receipts, split by PO: Importation POs -> impM, everything else -> inM (the Purchases row)
      (state.inboundRows || []).forEach(function (r) {
        if (!r.sku || !r.rcvTs) return; var d = new Date(r.rcvTs);
        if (d.getFullYear() !== cy || d.getMonth() !== cmo) return;
        var t = isImpPo(r) ? impM : inM; t[r.sku] = (t[r.sku] || 0) + (+r.rcvQty || 0);
      });
      var last = {};
      (state.inboundRows || []).forEach(function (r) { if (r.sku && r.rcvTs && (!last[r.sku] || r.rcvTs > last[r.sku])) last[r.sku] = r.rcvTs; });
      // v1.17.0 — repacked this month (repack sheet, APPLIED) and repack available now (damaged box)
      var repMtd = {}; (state.supplyRepackRows || []).forEach(function (x) { if (x.status !== "APPLIED" || !x.ts) return; var d = new Date(x.ts); if (d.getFullYear() === cy && d.getMonth() === cmo) repMtd[x.sku] = (repMtd[x.sku] || 0) + (+x.qty || 0); });
      var repAvail = state.repackMap instanceof Map ? state.repackMap : new Map();
      // expected returns — same logic as Purchase Plan (pending confirmed × (1 − DR%))
      var ov = null; try { ov = computePurchasePlanOverallSingleStats(); } catch (e) { ov = null; }
      var ids = {}; Object.keys(invMap).forEach(function (k) { ids[k] = 1; }); idx.stockByProductId.forEach(function (v, k) { ids[k] = 1; });
      Object.keys(ids).forEach(function (id) {
        var m = pm.get(id); if ((m && m.length > 1) || idx.isBundleByProductId.get(id) || (singles && singles.size && !singles.has(id))) return; // Single SKUs only
        var iv = invMap[id] || {}, pr = (state.productsMap || {})[id] || {};
        var stock = idx.stockByProductId.has(id) ? (+idx.stockByProductId.get(id) || 0) : (+iv.stock || 0), st = idx.singleOverallStats(id), wac = (state.cogsMap && state.cogsMap.get) ? (+state.cogsMap.get(id) || 0) : 0;
        var newest = last[id] || 0, days = newest ? Math.max(0, Math.round((today - newest) / DAY)) : null, ai = ageIdx(days), q = [0, 0, 0, 0, 0, 0];
        q[ai] = stock; var aging = AGES[ai];
        var a15 = (c15[id] || 0) / 15, a3 = (c3[id] || 0) / 3, doh = a3 === 0 ? stock : stock / a3;
        var tag = doh > 18 ? "5- Overstocked" : doh >= 10 ? "4- Fairly Stocked" : doh === 0 ? "1- OSS" : doh < 5 ? "2- At Risk" : "3- Understocked";
        var supply = (beg[id] || 0) + (inM[id] || 0), str = supply > 0 ? (mtd[id] || 0) / supply : null;
        var fms = str == null ? "0. No Stock" : str >= 0.7 ? FMS[0] : str >= 0.4 ? FMS[1] : str >= 0.1 ? FMS[2] : FMS[3];
        var o = ov && ov.get(id), drPct = o && o.drConfirmed ? o.drDelivered / o.drConfirmed * 100 : 0, exRet = o ? Math.round(Math.max(0, o.confirmed - o.delivered) * RET_FACTOR) : 0;
        var gA_ = gA[id] || 0, gL_ = gL[id] || 0, gP = elapsed >= 5 ? gA_ / elapsed * mdays : (gA_ / elapsed * mdays * elapsed + gL_ * (5 - elapsed)) / 5;
        var action = "", channel = "";
        var row = { id: id, name: iv.skuName || pr.name || id, cat: String(iv.category || pr.category || "").toLowerCase() || "general", lpd: newest ? new Date(newest).toISOString().slice(0, 10) : "", days: days, aging: aging, avg3: a3, avg15: a15, c15: c15[id] || 0, c30: c30[id] || 0, stock: stock, doh: doh, wac: wac, inv: stock * wac, tag: tag, fms: fms, abc: "", quarter: newest ? (new Date(newest).getFullYear() < 2026 ? "Before 2026" : new Date(newest).getMonth() <= 2 ? "Q1" : new Date(newest).getMonth() <= 5 ? "Q2" : "Q3") : "", mtd: mtd[id] || 0, str: str, action: action, channel: channel, exRet: exRet, retV: exRet * wac, drPct: drPct, gA: gA_, gL: gL_, gP: gP, segA: segOf(gA_), segL: segOf(gL_), segP: segOf(gP),
          asp: dP[id] > 0 ? dG[id] / dP[id] : null, aspPcs: dP[id] || 0, repMtd: repMtd[id] || 0, repAvail: repAvail.get(id) || 0,
          dMtd: dMtd[id] || 0, cogsC: (mtd[id] || 0) * wac, cogsD: (dMtd[id] || 0) * wac,
          imp: !!impSku[id], impPo: impPoOf[id] || "" };
        for (var z = 0; z < 6; z++) { row["q" + z] = q[z]; row["v" + z] = q[z] * wac; }
        rows.push(row);
      });
      // ---- Supply conversion (Targets page) — same waterfall as the Inventory Aging workbook (Working Sheet X/AB/AF/BR):
      // MTD confirmed is consumed from Beginning inventory first, then Purchases, then Returns, then Repack. Values = qty × WAC.
      var rep = {}; (state.supplyRepackRows || []).forEach(function (r) { if (r.status !== "APPLIED" || !r.ts) return; var d = new Date(r.ts); if (d.getFullYear() === ccy && d.getMonth() === ccmo) rep[r.sku] = (rep[r.sku] || 0) + (+r.qty || 0); });
      // the month picked at the top: same maps as above (beg / inM / impM / mtd), built for that month
      var begC = beg, inMC = inM, impMC = impM, mtdC = mtd;
      if (!convSame) {
        begC = {}; inMC = {}; impMC = {}; mtdC = {};
        (state.metabaseBeginningInventory || []).forEach(function (r) { var d = new Date(r.MONTH); if (isNaN(d.getTime()) || d.getUTCFullYear() !== ccy || d.getUTCMonth() !== ccmo) return; begC[r.PRODUCT_ID] = (begC[r.PRODUCT_ID] || 0) + (+r.QTY || 0); });
        (state.inboundRows || []).forEach(function (r) {
          if (!r.sku || !r.rcvTs) return; var d = new Date(r.rcvTs);
          if (d.getFullYear() !== ccy || d.getMonth() !== ccmo) return;
          var t = isImpPo(r) ? impMC : inMC; t[r.sku] = (t[r.sku] || 0) + (+r.rcvQty || 0);
        });
        main.forEach(function (r) {
          if (!r.sku || !r.confirmedPieces) return; var d = new Date(r.timestamp);
          if (d.getFullYear() !== ccy || d.getMonth() !== ccmo) return;
          mapsFor(r.sku).forEach(function (mp) { mtdC[mp.singleId] = (mtdC[mp.singleId] || 0) + r.confirmedPieces * (mp.quantity || 1); });
        });
      }
      var rto = {};
      // Returns = ACTUAL returns received this month (warehouse scans, "Product is good"), like the Inventory Aging sheet.
      var retMonth = ccy + "-" + String(ccmo + 1).padStart(2, "0"); loadActualReturns(retMonth);
      if (RET.data && RET.data.month === retMonth) { var rs = RET.data.skus || {}; Object.keys(rs).forEach(function (k) { var id = String(k).trim(); rto[id] = (rto[id] || 0) + (+rs[k] || 0); }); }
      SC.retInfo = RET.data && RET.data.month === retMonth ? RET.data : null; SC.retErr = RET.err; SC.retLoading = RET.loading;
      var cids = {}; [begC, inMC, impMC, rto, rep, mtdC].forEach(function (o) { Object.keys(o).forEach(function (k) { cids[k] = 1; }); });
      var conv = { all: null }, mkAgg = function () { return { beg: [0, 0], pur: [0, 0], ret: [0, 0], rep: [0, 0], imp: [0, 0] }; }; // [actual, converted]
      Object.keys(cids).forEach(function (id) {
        var m = pm.get(id); if ((m && m.length > 1) || idx.isBundleByProductId.get(id) || (singles && singles.size && !singles.has(id))) return;
        if (isExcluded(id)) { SC.exclN++; return; } // packaging, not product
        var w = (state.cogsMap && state.cogsMap.get) ? (+state.cogsMap.get(id) || 0) : 0; if (!w) return;
        var P = mtdC[id] || 0, V = begC[id] || 0, Z = inMC[id] || 0, I = impMC[id] || 0, R = rto[id] || 0, B = rep[id] || 0;
        // MTD confirmed is consumed in order: Beg Inv -> Purchases -> Importation -> Returns -> Repack.
        var X = P === 0 ? 0 : Math.min(V, P),
            AB = Math.min(P - X, Z),
            IM = Math.min(P - X - AB, I),
            AF = Math.min(P - X - AB - IM, R),
            BR = Math.max(0, Math.min(P - X - AB - IM - R, B));
        var iv = invMap[id] || {}, pr = (state.productsMap || {})[id] || {}, cat = String(iv.category || pr.category || "").toLowerCase() || "general";
        [["all"], [cat]].forEach(function (kk) {
          var a = conv[kk[0]] = conv[kk[0]] || mkAgg();
          a.beg[0] += V * w; a.beg[1] += X * w;
          a.pur[0] += Z * w; a.pur[1] += AB * w;
          a.imp[0] += I * w; a.imp[1] += IM * w;
          a.ret[0] += R * w; a.ret[1] += AF * w;
          a.rep[0] += B * w; a.rep[1] += BR * w;
        });
      });
      SC.conv = conv; SC.convMonth = cref.toLocaleDateString("en-GB", { month: "short", year: "numeric" }); SC.convElapsed = celapsed; SC.convMdays = cmdays; SC.convLatest = convSame;
      var tot = 0, cum = 0, sorted = rows.slice().sort(function (x, y) { return y.inv - x.inv; });
      rows.forEach(function (r) { tot += r.inv; });
      sorted.forEach(function (r) { cum += r.inv; r.abc = r.stock <= 0 ? "-" : cum / (tot || 1) <= 0.8 ? "A" : cum / (tot || 1) <= 0.95 ? "B" : "C"; var L = ACT_LOOKUP[r.abc + "_" + r.fms + "_" + r.quarter]; if (L) { r.action = L[0]; r.channel = L[1]; } });
      SC.rows = rows; SC.empty = !rows.length; SC.asOf = new Date().toISOString().slice(0, 10); SC.monthLbl = ref.toLocaleDateString("en-GB", { month: "short", year: "numeric" }); SC.elapsed = elapsed; SC.mdays = mdays;
    } catch (e) { SC.rows = []; SC.empty = true; SC.err = String(e && e.message || e); }
  }

  /* ---------------------------------------------------------------- Targets page: Supply conversion */
  // v1.17.0 — Planned comes from Control → Targets → "Supply conversion plan" (per month, saved on the Worker, same for everyone)
  var PLAN = null;
  function planKey() { return SC.convKey || (window.TaagerPlans ? window.TaagerPlans.keyOf(new Date()) : ""); }
  function planGet() {
    var P = window.TaagerPlans, key = planKey(); if (!P) return { beg: 0, pur: 0, ret: 0, rep: 0 };
    var have = P.peek("supplyplan", key);
    if (have) { PLAN = have; return have.values; }
    P.get("supplyplan", key).then(function (p) { PLAN = p; rerender(); });
    return P.SUPPLY_DEF;
  }
  // v1.17.0 — the six numbers behind every row of the Supply conversion table.
  //   Actual              = the COGS this source made available this month
  //   Planned             = what the plan expected it to make available (Control -> Targets)
  //   Target%             = the share it is expected to convert (Control -> Targets). SHOWN ONLY —
  //                         it is the line you read the two percentages against and is deliberately
  //                         not multiplied into anything, so no number here moves when it is edited.
  //   Converted           = the COGS that has actually converted out of it so far (EGP)
  //   Conversion %        = Converted / Planned     — against the plan
  //   Converted vs Actual = Converted / Actual      — against what actually turned up
  var CONV_ROWS = [["beg", "Beg Inv.", "tbeg"], ["pur", "Purchases", "tpur"], ["imp", "Importation", "timp"],
                   ["ret", "Returns", "tret"], ["rep", "Repack", "trep"]];
  function convCalc() {
    var d = SC.conv && SC.conv[SC.cat === "all" ? "all" : SC.cat]; if (!d) return null;
    var pl = planGet();
    return CONV_ROWS.map(function (l) {
      var actual = Math.round(d[l[0]][0]), converted = Math.round(d[l[0]][1]);
      var planned = Math.round(+pl[l[0]] || 0);
      return { metric: l[1], actual: actual, planned: planned, targetPct: +pl[l[2]] || 0, converted: converted,
               conversionPct: planned > 0 ? converted / planned : 0,
               convertedVsActual: actual > 0 ? converted / actual : 0 };
    });
  }

  // v1.17.0 — the five rows of the Supply conversion panel, exactly as rendered, ready to be sent
  // to the Apps Script so the sheet carries the dashboard's own numbers instead of a second calculation.
  function convExport() {
    var save = SC.cat; SC.cat = "all";
    var rows = convCalc(); SC.cat = save;
    if (!rows) return null;
    return { rows: rows, monthKey: SC.convKey || "", monthLabel: SC.convMonth || "", elapsed: SC.convElapsed != null ? SC.convElapsed : (SC.elapsed || 0), daysInMonth: SC.convMdays || SC.mdays || 0, latest: SC.convLatest !== false,
             skus: (SC.rows || []).length, excludedEnds: SC.exclEnds || [], excluded: SC.exclN || 0,
             importPos: SC.impPo || [], importLines: SC.impLines || 0, asOf: SC.asOf || "" };
  }

  var ICON_SHEET = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>';

  // v1.17.0 — "Send to sheet": the same table, written to the planning sheet on demand, so the
  // numbers can be pushed the moment a plan changes instead of waiting for the 11:30 Cairo run.
  // publishSupplyConversion() posts no-cors, so there is no reply to read — the button reports
  // that it was sent, and cell A1 of the tab carries the timestamps that prove it landed.
  function convPush(btn) {
    var say = function (txt, cls) { var sp = btn.querySelector("span"); if (sp) sp.textContent = txt; btn.className = "tw-exp" + (cls ? " " + cls : ""); };
    if (typeof window.publishSupplyConversion !== "function") { say("Not available", "bad"); return; }
    var rows = convCalc();
    if (!rows || !rows.length) { say("Nothing to send yet", "bad"); setTimeout(function () { say("Send to sheet"); }, 2600); return; }
    btn.disabled = true; say("Sending\u2026", "busy");
    window.publishSupplyConversion({ manual: true }).then(function (r) {
      say(r && r.ok ? "Sent \u2713" : ((r && r.error) || "Failed"), r && r.ok ? "ok" : "bad");
    }, function (e) {
      say((e && e.message) || "Failed", "bad");
    }).then(function () {
      setTimeout(function () { btn.disabled = false; say("Send to sheet"); }, 3200);
    });
  }

  // v1.17.0 — "Send to sheet" for the per-category table, same behaviour as the Supply conversion one.
  function catPush(btn) {
    var say = function (txt, cls) { var sp = btn.querySelector("span"); if (sp) sp.textContent = txt; btn.className = "tw-exp cx-cardbtn" + (cls ? " " + cls : ""); };
    if (typeof window.publishInvCategory !== "function") { say("Not available", "bad"); return; }
    var rows = catCalc();
    if (!rows || !rows.length) { say("Nothing to send yet", "bad"); setTimeout(function () { say("Send to sheet"); }, 2600); return; }
    btn.disabled = true; say("Sending\u2026", "busy");
    window.publishInvCategory().then(function (r) {
      say(r && r.ok ? "Sent \u2713" : ((r && r.error) || "Failed"), r && r.ok ? "ok" : "bad");
    }, function (e) {
      say((e && e.message) || "Failed", "bad");
    }).then(function () {
      setTimeout(function () { btn.disabled = false; say("Send to sheet"); }, 3200);
    });
  }

  function convPanel() {
    var rows = convCalc() || CONV_ROWS.map(function (l) { return { metric: l[1], actual: 0, planned: 0, targetPct: 0, converted: 0, conversionPct: 0, convertedVsActual: 0 }; });
    var body = rows.map(function (r) {
      var pc = r.conversionPct * 100, hit = r.targetPct > 0 && r.conversionPct >= r.targetPct;
      return '<tr><td>' + esc(r.metric) + '</td>' +
        '<td class="num">' + int(r.actual) + '</td>' +
        '<td class="num" title="What the plan expected this source to make available \u2014 Control \u2192 Targets \u2192 Supply conversion plan.">' + int(r.planned) + '</td>' +
        '<td class="num text-dim" title="The share this source is expected to convert \u2014 the line to read the two percentages against. Edit in Control \u2192 Targets \u2192 Supply conversion plan.">' + (r.targetPct * 100).toFixed(0) + '%</td>' +
        '<td class="num"><b>' + int(r.converted) + '</b></td>' +
        '<td class="num ' + (hit ? "text-green" : "") + '" style="min-width:150px"><b>' + pc.toFixed(2) + '%</b>' + bar(pc, "ok", "sm") + '</td>' +
        '<td class="num"><b>' + (r.convertedVsActual * 100).toFixed(2) + '%</b></td></tr>';
    }).join("");
    return '<div class="panel table-panel hover-glow" style="margin-top:14px"><div class="panel-head-modern"><div class="panel-title-wrapper border-blue"><h2>Supply conversion \u2014 ' + esc(SC.convMonth || "") + '</h2><p>Actual \u00b7 Planned \u00b7 Converted \u2014 per source</p></div><button type="button" class="tw-exp" id="scConvPush" title="Write this exact table into the Supply conversion tab of the planning sheet.">' + ICON_SHEET + '<span>Send to sheet</span></button></div><div class="table-responsive"><table class="data-table"><thead><tr><th>Metric</th>' +
      '<th class="num" title="Quantity \u00d7 WAC this source made available this month.">Actual</th>' +
      '<th class="num" title="What the plan expected this source to make available this month \u2014 Control \u2192 Targets \u2192 Supply conversion plan.">Planned</th>' +
      '<th class="num" title="The share this source is expected to convert. Shown as the line to read the two percentages against \u2014 nothing is multiplied by it.">Target%</th>' +
      '<th class="num" title="The COGS that has actually converted out of this source so far this month.">Converted</th>' +
      '<th class="num" title="Converted \u00f7 Planned \u2014 how the conversion reads against the plan. Green once it passes Target%.">Conversion %</th>' +
      '<th class="num" title="Converted \u00f7 Actual \u2014 how it reads against what actually turned up, which can differ a lot from the plan.">Converted vs Actual</th></tr></thead><tbody>' + body + '</tbody></table></div><div class="sc-note" style="margin:12px 16px">Values are COGS (quantity \u00d7 WAC), single SKUs only. Converted = the MTD confirmed COGS consumed from each source, in order: Beg Inv \u2192 Purchases \u2192 Importation \u2192 Returns \u2192 Repack. <b>Target%</b> is a reference only \u2014 read <b>Conversion %</b> (against the plan) and <b>Converted vs Actual</b> (against what really arrived) against it; neither is multiplied by it, and no figure above changes when it is edited. <b>Importation</b> = the pieces received this month under an Importation PO; the Purchases row is everything received under any other PO, so the two never count the same piece twice.</div>' + impNote() + exclNote() + retNote() + '<div class="sc-note" style="margin:0 16px 12px">Planned: ' + esc(window.TaagerPlans ? window.TaagerPlans.sourceText(PLAN) : "") + ' (Control \u2192 Targets \u2192 Supply conversion plan).</div></div>';
  }
  function exclNote() {
    var e = SC.exclEnds || []; if (!e.length) return "";
    return '<div class="sc-note" style="margin:0 16px 12px">Left out as packaging: SKUs ending with ' + esc(e.join(", ")) + ' — ' + int(SC.exclN || 0) + ' SKU' + ((SC.exclN || 0) === 1 ? "" : "s") + ' skipped this month.</div>';
  }
  function impNote() {
    var n = (SC.impPo || []).length;
    if (!n) return '<div class="sc-note" style="margin:0 16px 12px">Importation: no PO numbers set yet — add them in Control → Targets → Supply conversion plan.</div>';
    return '<div class="sc-note" style="margin:0 16px 12px">Importation POs (' + n + '): ' + esc((SC.impPo || []).join(", ")) + ' → ' + int(SC.impLines || 0) + ' inbound line' + ((SC.impLines || 0) === 1 ? "" : "s") + ' on ' + int(SC.impSkuN || 0) + ' SKU' + ((SC.impSkuN || 0) === 1 ? "" : "s") + '. Only what was received <b>this month</b> under these POs counts in the Importation row.</div>';
  }
  function retNote() {
    var I = SC.retInfo, t;
    if (I) {
      var when = function (x) { try { return new Date(x).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); } catch (e) { return x; } };
      t = "Returns = actual returns scanned in the warehouse this month with condition \"Product is good\" (" + esc(I.file || "Return_Archive") + " → Return_RCV · " + int(I.total) + " pieces" + (I.lastScan ? " · last scan " + when(I.lastScan) : "") + ").";
      if (I.source === "cache") t = "⚠ " + t + " Cached from " + when(I.cachedAt) + " — " + esc(I.reason || "source problem") + ".";
    } else if (SC.retLoading) t = "Loading the actual returns (Return_Archive)…";
    else t = "⚠ Actual returns could not be loaded" + (SC.retErr ? " (" + esc(SC.retErr) + ")" : "") + " — the Returns row is empty until it loads.";
    return '<div class="sc-note" style="margin:0 16px 12px">' + t + '</div>';
  }
  function boot() { build(); }

  /* ---------------------------------------------------------------- helpers */
  function scoped() { return SC.cat === "all" ? SC.rows : SC.rows.filter(function (r) { return r.cat === SC.cat; }); }
  function sum(rows, k) { var s = 0; rows.forEach(function (r) { s += +r[k] || 0; }); return s; }
  function groupBy(rows, k) { var m = {}; rows.forEach(function (r) { (m[r[k]] = m[r[k]] || []).push(r); }); return m; }
  function bar(p, tone, h) { return '<div class="cx-bar ' + (h || "sm") + ' cx-' + tone + '"><b style="width:' + Math.max(0, Math.min(100, p)) + '%"></b></div>'; }
  function chip(t, tone) { return '<i class="cx-chip cx-' + tone + '">' + esc(t) + '</i>'; }
  function segChip(g) { return chip(g, g === "Normal" ? "na" : "ok"); }
  function ageChip(a) { var i = AGES.indexOf(a); var tone = i < 0 ? "na" : i < 2 ? "ok" : i === 2 ? "warn" : "bad"; return chip(AGE_LBL[a] || a || "—", tone); }
  function dohTxt(r) { return r.stock > 0 ? (r.doh >= 999 ? "999+" : int(r.doh)) : "—"; }
  function dohVal(rows) { var dv = rows.reduce(function (a, r) { return a + (r.avg15 || 0) * (r.wac || 0); }, 0); return dv > 0 ? sum(rows, "inv") / dv : 0; }
  function srcChip() { return ""; }
  function catPills() {
    return '<div class="cx-pills">' + ["all"].concat(CATS).map(function (c) { return '<button type="button" class="cx-pill' + (SC.cat === c ? " on" : "") + '" data-sc-cat="' + c + '">' + (c === "all" ? "All categories" : CATL[c]) + '</button>'; }).join("") + '</div>';
  }
  function dist(rows, key, order, valKey, labelFn, colorFn) {
    var g = groupBy(rows, key), tot = sum(rows, valKey) || 1;
    return order.map(function (k, i) {
      var rs = g[k] || [], v = sum(rs, valKey), p = v / tot * 100;
      return '<div class="sc-drow"><span class="sc-dl">' + esc(labelFn ? labelFn(k) : k) + '<small>' + int(rs.length) + ' SKUs</small></span><div class="cx-bar sm" style="--c:' + colorFn(k, i) + '"><b style="width:' + p + '%"></b></div><em>' + money(v) + '<small>' + pct(p, 0) + '</small></em></div>';
    }).join("");
  }

  /* ---------------------------------------------------------------- views */
  function mkSection(id) { var main = document.querySelector("main.content"); if (main && !$(id)) { var d = document.createElement("div"); d.id = id; d.className = "view-section hidden"; main.appendChild(d); } }
  function bsum(rows, i) { return sum(rows, "v" + i); }
  function distV(items, tot) {
    return items.map(function (it) { var p = tot ? it.v / tot * 100 : 0; return '<div class="sc-drow"><span class="sc-dl">' + esc(it.l) + '<small>' + int(it.n) + ' SKUs</small></span><div class="cx-bar sm" style="--c:' + it.c + '"><b style="width:' + p + '%"></b></div><em>' + money(it.v) + '<small>' + pct(p, 0) + '</small></em></div>'; }).join("");
  }
  // Damaged BOX (WareHouse sheet, Condition = "Damaged BOX"): qty and value (qty × WAC) over the SKUs in the current category filter.
  function damagedBox(rows) {
    var all = SC.cat === "all", ids = {}; rows.forEach(function (r) { ids[r.id] = 1; });
    var qty = 0, val = 0, n = 0;
    ((state.repackMap && state.repackMap.forEach) ? state.repackMap : new Map()).forEach(function (q, id) {
      if (!(q > 0) || (!all && !ids[id])) return;
      var w = (state.cogsMap && state.cogsMap.get) ? (+state.cogsMap.get(id) || 0) : 0;
      qty += q; val += q * w; n++;
    });
    return { qty: qty, val: val, n: n };
  }
  // v1.17.0 — Inventory & DOH per category, exactly as the Inventory Aging page shows them, ready to
  // be written into the planning sheet. The page is the only place these are worked out.
  //   Inventory value = Σ (stock × WAC)                     · Pieces = Σ stock (Good item only)
  //   DOH (value)     = inventory value ÷ Σ (avg15 × WAC)   — the figure on the "Days on hand" tile
  //   DOH (pcs)       = pieces ÷ Σ avg15                    — the same idea counted in pieces
  // Every category is sent whether or not the page is filtered to one: the pills are for looking at
  // the page, and must never decide what the planning team receives.
  function catRowsFor(rs) {
    var pcs = sum(rs, "stock"), inv = sum(rs, "inv");
    var dAvg = rs.reduce(function (a, r) { return a + (+r.avg15 || 0); }, 0);
    return { skus: rs.filter(function (r) { return r.stock > 0; }).length,
             pcs: Math.round(pcs), value: Math.round(inv),
             dohValue: dohVal(rs), dohPcs: dAvg > 0 ? pcs / dAvg : 0,
             avg15Pcs: dAvg, avg15Value: rs.reduce(function (a, r) { return a + (+r.avg15 || 0) * (+r.wac || 0); }, 0) };
  }
  function catCalc() {
    var all = SC.rows || []; if (!all.length) return null;
    var seen = {}; all.forEach(function (r) { seen[r.cat] = 1; });
    // the five known categories first, then anything else the data actually carries
    var list = CATS.filter(function (c) { return seen[c]; })
      .concat(Object.keys(seen).filter(function (c) { return CATS.indexOf(c) < 0; }).sort());
    var rows = list.map(function (c) {
      var o = catRowsFor(all.filter(function (r) { return r.cat === c; }));
      o.category = CATL[c] || c; return o;
    });
    var tot = catRowsFor(all); tot.category = "TOTAL";
    return rows.concat([tot]);
  }
  function catExport() {
    var rows = catCalc(); if (!rows) return null;
    return { rows: rows, asOf: SC.asOf || "", monthLabel: SC.monthLbl || "",
             elapsed: SC.elapsed || 0, daysInMonth: SC.mdays || 0 };
  }

  function renderAging(host) {
    var rows = scoped(), inv = sum(rows, "inv"), stocked = rows.filter(function (r) { return r.stock > 0; });
    var unh = bsum(rows, 4), dead = stocked.filter(function (r) { return r.fms === FMS[3]; }), retV = sum(rows, "retV");
    var dmg = damagedBox(rows);
    var tiles = [
      ["Inventory value", money(inv), int(sum(rows, "stock")) + " units on hand", ""],
      ["SKUs in stock", int(stocked.length), "of " + int(rows.length) + " SKUs in inventory", ""],
      ["Unhealthy stock", pct(inv ? unh / inv * 100 : 0, 0), money(unh) + " at 12m+ aging", (inv && unh / inv > 0.3) ? "bad" : "warn"],
      ["Days on hand", int(dohVal(rows)), "Good item stock value ÷ 15-day avg daily demand value — Damaged BOX not included (repacked pieces count once the warehouse marks them Good item)", ""],
      ["Obsolete stock", money(sum(dead, "inv")), int(dead.length) + " SKUs · sold < 10% of supply MTD", dead.length ? "bad" : "ok"],
      ["Expected returns", money(retV), int(sum(rows, "exRet")) + " pcs · (Confirmed − Delivered) × 75%", ""],
      ["Damaged BOX value", money(dmg.val), int(dmg.n) + " SKUs · qty × WAC", dmg.val ? "warn" : ""],
      ["Damaged BOX qty", int(dmg.qty), "pieces in Damaged BOX condition", dmg.qty ? "warn" : ""],
      // v1.17.0 — what the month's sales actually cost, at WAC. Confirmed is what was sold, Delivered is
      // what reached the customer; the gap is the orders still in transit (and the ones that come back).
      ["Confirmed COGS", money(sum(rows, "cogsC")), int(sum(rows, "mtd")) + " pcs confirmed MTD \u00d7 WAC", ""],
      ["Delivered COGS", money(sum(rows, "cogsD")), int(sum(rows, "dMtd")) + " pcs delivered MTD \u00d7 WAC", ""]
    ];
    var html = '<div class="cx-bar-top"><div>' + catPills() + '</div>' + srcChip() + '</div>' +
      '<div class="cx-hero2">' + tiles.map(function (t) { return '<div class="cx-tile ' + (t[3] ? "cx-" + t[3] : "") + '"><span>' + t[0] + '</span><b>' + t[1] + '</b><small>' + t[2] + '</small></div>'; }).join("") + '</div>';
    var cats = SC.cat === "all" ? CATS : [SC.cat];
    var stack = cats.map(function (c) {
      var rs = SC.rows.filter(function (r) { return r.cat === c; }), tv = sum(rs, "inv") || 1;
      return '<div class="sc-stk"><span class="sc-stk-l">' + CATL[c] + '<small>' + money(sum(rs, "inv")) + '</small></span><div class="sc-stk-b">' + AGES.map(function (a, i) { var v = bsum(rs, i); return v > 0 ? '<i style="width:' + (v / tv * 100) + '%;background:' + AGE_COL[i] + '" title="' + AGE_LBL[a] + ' · ' + money(v) + '"></i>' : ""; }).join("") + '</div></div>';
    }).join("");
    var ageItems = AGES.map(function (a, i) { return { l: AGE_LBL[a], c: AGE_COL[i], v: bsum(rows, i), n: rows.filter(function (r) { return r["q" + i] > 0; }).length }; });
    html += '<div class="cx-grid2"><div class="panel cx-card"><div class="cx-card-h">Inventory value by aging <small>per category</small><button type="button" class="tw-exp cx-cardbtn" id="scCatPush" title="Write inventory value, pieces and DOH per category into the planning sheet.">' + ICON_SHEET + '<span>Send to sheet</span></button></div>' + stack +
      '<div class="sc-legend">' + AGES.map(function (a, i) { return '<span><i style="background:' + AGE_COL[i] + '"></i>' + AGE_LBL[a] + '</span>'; }).join("") + '</div></div>' +
      '<div class="panel cx-card"><div class="cx-card-h">Aging buckets <small>value · share</small></div>' + distV(ageItems, inv) + '</div></div>';
    var segTone = ["#0ea58a", "#7c5cf0", "#3b82f6", "#fbbf24", "#9aa7bd"], sm = SC.segMode, smL = { segA: "Actual (MTD)", segL: "Last month", segP: "Projected" };
    var segItems = SEGS.map(function (g, i) { var rs = stocked.filter(function (r) { return r[sm] === g; }); return { l: g, c: segTone[i], v: sum(rs, "inv"), n: rs.length }; });
    html += '<div class="cx-grid2"><div class="panel cx-card"><div class="cx-card-h">Stock health <small>inventory tag (DOH)</small></div>' + dist(stocked, "tag", TAGS.slice(0, 4), "inv", null, function (k) { return ({ ok: "#34d399", warn: "#fbbf24", bad: "#fb7185", na: "#74839a" })[TAG_TONE[k]]; }) + '</div>' +
      '<div class="panel cx-card"><div class="cx-card-h">Product segment <small>confirmed GMV · inventory value</small></div><div class="cx-pills" style="margin-bottom:10px">' + ["segA", "segL", "segP"].map(function (k) { return '<button type="button" class="cx-pill' + (sm === k ? " on" : "") + '" data-sc-seg="' + k + '">' + smL[k] + '</button>'; }).join("") + '</div>' + distV(segItems, sum(stocked, "inv")) +
      '<div class="sc-note" style="margin-bottom:0">Monthly confirmed GMV: Mega ≥ 1.2M · Super ≥ 400K · Winning ≥ 200K · Potential Winning ≥ 100K. Actual = ' + esc(SC.monthLbl || "") + ' so far (day ' + SC.elapsed + '/' + SC.mdays + '); Projected = run-rate to month end' + (SC.elapsed < 5 ? ' (blended with last month early in the month)' : '') + '.</div></div></div>';
    var top = rows.filter(function (r) { return r.stock > 0 && (r.v3 + r.v4) > 0 && r.lpd && new Date(r.lpd).getFullYear() === new Date().getFullYear(); }).sort(function (a, b) { return (b.v3 + b.v4) - (a.v3 + a.v4); }).slice(0, 8);
    html += convPanel().replace('margin-top:14px', 'margin:0 0 14px');
    html += '<div class="panel cx-card"><div class="cx-card-h">Biggest capital stuck in aged stock <small>6m+ aging · bought this year · click for details</small></div>' + top.map(function (r) {
      return '<div class="cx-lrow" data-sc-sku="' + esc(r.id) + '"><div><b>' + esc(r.name) + '</b><small>' + esc(r.id) + ' · ' + esc(CATL[r.cat] || r.cat) + ' · last inbound ' + dfmt(r.lpd) + '</small></div><div class="cx-lr"><b>' + money(r.v3 + r.v4) + '</b><small>' + int(r.stock) + ' pcs · DOH ' + dohTxt(r) + '</small>' + ageChip(r.aging) + '</div></div>';
    }).join("") + '</div>';
    host.innerHTML = html;
  }

  var COLS = [["id", "SKU ID", ""], ["name", "SKU name", ""], ["cat", "Category", ""], ["lpd", "Last inbound", ""], ["aging", "Aging", ""], ["avg3", "Avg 3D", "num"], ["avg15", "Avg 15D", "num"], ["stock", "Stock", "num"], ["doh", "DOH", "num"], ["wac", "WAC", "num"], ["asp", "ASP", "num"], ["impPo", "Importation PO", ""], ["inv", "Inv. value", "num"], ["repMtd", "Repacked MTD", "num"], ["repAvail", "Repack avail.", "num"], ["exRet", "Exp. returns", "num"], ["tag", "Stock tag", ""], ["segA", "Segment", ""], ["segL", "Last month", ""], ["segP", "Projected", ""], ["fms", "Movement", ""], ["abc", "ABC", ""], ["action", "Proposed action", ""]];
  function sel(id, label, opts, v) { return '<select data-sk="' + id + '"><option value="">' + label + '</option>' + opts.map(function (o) { return '<option value="' + esc(o) + '"' + (o === v ? " selected" : "") + '>' + esc(CATL[o] || o) + '</option>'; }).join("") + '</select>'; }
  function skuFiltered() {
    var f = SC.sk, q = f.q.toLowerCase();
    var rows = SC.rows.filter(function (r) {
      if (f.instock && !(r.stock > 0)) return false;
      if (f.repack === "done" && !(r.repMtd > 0)) return false; if (f.repack === "avail" && !(r.repAvail > 0)) return false; if (f.repack === "any" && !(r.repMtd > 0 || r.repAvail > 0)) return false; if (f.repack === "imp" && !r.imp) return false;
      if (f.cat && r.cat !== f.cat) return false; if (f.aging && r.aging !== f.aging) return false; if (f.tag && r.tag !== f.tag) return false; if (f.seg && r.segA !== f.seg) return false; if (f.action && r.action !== f.action) return false;
      if (q && (String(r.id).toLowerCase().indexOf(q) < 0 && String(r.name).toLowerCase().indexOf(q) < 0)) return false; return true;
    });
    var k = f.key, d = f.dir === "asc" ? 1 : -1;
    rows.sort(function (a, b) { var x = a[k], y = b[k]; if (typeof x === "string" || typeof y === "string") return String(x || "").localeCompare(String(y || "")) * d; return ((x || 0) - (y || 0)) * d; });
    return rows;
  }
  function renderSkus(host) {
    var f = SC.sk;
    if (!$("scSkuTable")) {
      host.innerHTML = '<div class="cx-bar-top"><div class="sc-hdr">Every SKU with stock, aging, health tag and the proposed action</div>' + srcChip() + '</div><div class="sc-stats" id="scSkuStats"></div>' +
        '<div class="panel table-panel"><div class="panel-head-modern"><div class="panel-title-wrapper border-blue"><h2>SKU analysis</h2><p>Stock, aging, returns and segment per SKU</p></div><div class="table-controls sc-filters" id="scSkuFilters"></div></div>' +
        '<div class="table-responsive"><table class="data-table" id="scSkuTable"><thead><tr>' + COLS.map(function (c) { return '<th class="' + c[2] + '" data-k="' + c[0] + '" style="cursor:pointer">' + c[1] + '</th>'; }).join("") + '</tr></thead><tbody id="scSkuBody"></tbody></table></div>' +
        '<div class="table-footer"><span id="scSkuCount"></span><div class="pager"><button class="btn btn-outline small" data-sc="prev">Prev</button><span id="scSkuPage"></span><button class="btn btn-outline small" data-sc="next">Next</button></div></div></div>';
    } else { var sc = host.querySelector(".sc-src"); }
    $("scSkuFilters").innerHTML = '<input type="search" id="scSkuQ" placeholder="Search SKU ID or name…" value="' + esc(f.q) + '" autocomplete="off" />' + sel("cat", "All categories", CATS, f.cat) + sel("aging", "All aging", AGES, f.aging) + sel("tag", "All stock tags", TAGS, f.tag) + sel("seg", "All segments", SEGS, f.seg) + sel("action", "All actions", ACTIONS, f.action) +
      '<select data-sk="repack"><option value="">All (repack / importation)</option>' + [["done", "Repacked this month"], ["avail", "Repack available (damaged box)"], ["any", "Repacked or available"], ["imp", "Importation SKUs"]].map(function (o) { return '<option value="' + o[0] + '"' + (f.repack === o[0] ? " selected" : "") + '>' + o[1] + '</option>'; }).join("") + '</select>' +
      '<label class="sc-chk"><input type="checkbox" data-sk="instock"' + (f.instock ? " checked" : "") + '> In stock only</label>';
    var q = $("scSkuQ"); if (q && document.activeElement !== q && f.q) { /* keep */ }
    drawSkuBody();
  }
  function drawSkuBody() {
    var rows = skuFiltered(), f = SC.sk, PG = window.__dashExport ? Math.max(1, rows.length) : PAGE, tp = Math.max(1, Math.ceil(rows.length / PG)); if (f.page >= tp) f.page = tp - 1;
    var pg = rows.slice(f.page * PG, f.page * PG + PG);
    $("scSkuBody").innerHTML = pg.length ? pg.map(function (r) {
      return '<tr class="cx-row" data-sc-sku="' + esc(r.id) + '"><td class="font-mono text-dim">' + esc(r.id) + '</td><td class="truncate-cell" title="' + esc(r.name) + '">' + esc(r.name) + '</td><td class="text-dim">' + esc(CATL[r.cat] || r.cat) + '</td><td class="text-dim">' + dfmt(r.lpd) + '</td><td>' + ageChip(r.aging) + '</td><td class="num">' + (+r.avg3).toFixed(1) + '</td><td class="num">' + (+r.avg15).toFixed(1) + '</td><td class="num font-bold">' + int(r.stock) + '</td><td class="num">' + dohTxt(r) + '</td><td class="num text-dim">' + moneyC(r.wac) + '</td><td>' + (r.imp ? '<span class="badge-outline blue" title="Received under Importation PO ' + esc(r.impPo) + '">' + esc(r.impPo) + '</span>' : '<span class="text-dim">—</span>') + '</td><td class="num" title="Delivered GMV ÷ delivered pieces, last 30 days (' + int(r.aspPcs) + ' pcs)">' + (r.asp == null ? '<span class="text-dim">—</span>' : int(r.asp)) + '</td><td class="num font-bold">' + moneyC(r.inv) + '</td><td class="num ' + (r.repMtd > 0 ? 'text-blue font-bold' : 'text-dim') + '">' + (r.repMtd > 0 ? int(r.repMtd) : '—') + '</td><td class="num ' + (r.repAvail > 0 ? 'text-orange' : 'text-dim') + '">' + (r.repAvail > 0 ? int(r.repAvail) : '—') + '</td><td class="num ' + (r.exRet > 0 ? '' : 'text-dim') + '">' + int(r.exRet) + '</td><td>' + chip(r.tag.replace(/^\d-\s*/, "") || "—", TAG_TONE[r.tag] || "na") + '</td><td>' + segChip(r.segA) + '</td><td class="text-dim">' + esc(r.segL) + '</td><td class="text-dim">' + esc(r.segP) + '</td><td class="text-dim">' + esc((r.fms || "").replace(/^\d\.\s*/, "")) + '</td><td class="text-dim">' + esc(r.abc) + '</td><td class="text-dim truncate-cell">' + esc(r.action) + '</td></tr>';
    }).join("") : '<tr><td colspan="' + COLS.length + '" class="text-dim center">No SKUs match these filters.</td></tr>';
    $("scSkuCount").textContent = int(rows.length) + " SKUs"; $("scSkuPage").textContent = "Page " + (f.page + 1) + " of " + tp;
    var st = $("scSkuStats"); if (st) st.innerHTML = [["SKUs", int(rows.length)], ["Units", int(sum(rows, "stock"))], ["Inventory value", money(sum(rows, "inv"))], ["Avg DOH", int(dohVal(rows))]].map(function (t) { return '<div class="cx-tile"><span>' + t[0] + '</span><b>' + t[1] + '</b></div>'; }).join("");
  }

  function renderActions(host) {
    var stocked = SC.rows.filter(function (r) { return r.stock > 0; }), cur = SC.act;
    var cards = ACTIONS.map(function (a) {
      var rs = stocked.filter(function (r) { return r.action === a; }), ch = (ACT_LOOKUP[Object.keys(ACT_LOOKUP).filter(function (k) { return ACT_LOOKUP[k][0] === a; })[0]] || [])[1] || "";
      return '<button type="button" class="sc-act' + (a === cur ? " on" : "") + '" data-sc-act="' + esc(a) + '"><b>' + esc(a) + '</b><span>' + esc(ACT_NOTE[a]) + '</span><div class="sc-act-n">' + money(sum(rs, "inv")) + '</div><small>' + int(rs.length) + ' SKUs · ' + int(sum(rs, "stock")) + ' pcs' + (ch ? " · " + esc(ch) : "") + '</small></button>';
    }).join("");
    var none = [];
    var rs = stocked.filter(function (r) { return r.action === cur; }).sort(function (a, b) { return b.inv - a.inv; });
    var tot = sum(rs, "inv");
    host.innerHTML = '<div class="cx-bar-top"><div class="sc-hdr">Proposed action per SKU — ABC × FMS × purchase period (Lookups sheet)</div>' + srcChip() + '</div><div class="sc-acts">' + cards + '</div>' +
      (none.length ? '<div class="sc-note">' + int(none.length) + ' aged SKUs (' + money(sum(none, "inv")) + ') have no proposed action yet.</div>' : "") +
      '<div class="panel table-panel"><div class="panel-head-modern"><div class="panel-title-wrapper border-orange"><h2>' + esc(cur) + '</h2><p>' + esc(ACT_NOTE[cur]) + ' · ' + int(rs.length) + ' SKUs · ' + money(tot) + '</p></div></div><div class="table-responsive"><table class="data-table" id="scActTable"><thead><tr><th>SKU ID</th><th>SKU name</th><th>Category</th><th>Aging</th><th class="num">Stock</th><th class="num">Avg 3D</th><th class="num">DOH</th><th class="num">WAC</th><th class="num">Inv. value</th><th class="num">Share</th><th>Movement</th><th>ABC</th></tr></thead><tbody>' +
      (rs.slice(0, window.__dashExport ? rs.length : 100).map(function (r) { return '<tr class="cx-row" data-sc-sku="' + esc(r.id) + '"><td class="font-mono text-dim">' + esc(r.id) + '</td><td class="truncate-cell" title="' + esc(r.name) + '">' + esc(r.name) + '</td><td class="text-dim">' + esc(CATL[r.cat] || r.cat) + '</td><td>' + ageChip(r.aging) + '</td><td class="num font-bold">' + int(r.stock) + '</td><td class="num">' + (+r.avg3).toFixed(1) + '</td><td class="num">' + dohTxt(r) + '</td><td class="num text-dim">' + moneyC(r.wac) + '</td><td class="num font-bold">' + moneyC(r.inv) + '</td><td class="num">' + pct(tot ? r.inv / tot * 100 : 0, 1) + '</td><td class="text-dim">' + esc((r.fms || "").replace(/^\d\.\s*/, "")) + '</td><td class="text-dim">' + esc(r.abc) + '</td></tr>'; }).join("") || '<tr><td colspan="12" class="text-dim center">No SKUs for this action.</td></tr>') + '</tbody></table></div>' + (rs.length > 100 ? '<div class="table-footer"><span>Showing top 100 of ' + int(rs.length) + ' by inventory value</span></div>' : "") + '</div>';
  }

  /* ---------------------------------------------------------------- drawer + connect modal */
  function kv(k, v) { return '<div class="tw-dstat"><span>' + k + '</span><b>' + v + '</b></div>'; }
  function openSku(id) {
    var r = SC.rows.filter(function (x) { return String(x.id) === String(id); })[0]; if (!r) return;
    var old = $("scDrawer"); if (old) old.remove();
    var D = document.createElement("div"); D.id = "scDrawer"; D.className = "tw-drawer";
    var sec = function (t, items) { return '<div class="cx-sec-t" style="margin:14px 0 8px">' + t + '</div><div class="tw-dstats">' + items.join("") + '</div>'; };
    D.innerHTML = '<div class="tw-dback"></div><div class="tw-dpanel"><div class="tw-dhead"><div><h3>' + esc(r.name) + '</h3><small>' + esc(r.id) + ' · ' + esc(CATL[r.cat] || r.cat) + ' · last purchase ' + dfmt(r.lpd) + '</small></div><button type="button" class="tw-dx">×</button></div><div class="tw-dbody"><div style="display:flex;gap:6px;flex-wrap:wrap">' + ageChip(r.aging) + chip((r.tag || "—").replace(/^\d-\s*/, ""), TAG_TONE[r.tag] || "na") + (r.action ? chip(r.action, "warn") : "") + '</div>' +
      sec("Stock", [kv("On hand", int(r.stock)), kv("DOH", dohTxt(r)), kv("WAC", money(r.wac)), kv("Inventory value", money(r.inv)), kv("Movement", esc((r.fms || "—").replace(/^\d\.\s*/, ""))), kv("ABC", esc(r.abc || "—"))]) +
      sec("Returns", [kv("Expected returns", int(r.exRet)), kv("Returns value", money(r.retV)), kv("DR%", pct(r.drPct, 1)), kv("Stock + returns", int(r.stock + r.exRet))]) +
      sec("Segment (confirmed GMV)", [kv("Actual MTD", money(r.gA) + ' · ' + esc(r.segA)), kv("Last month", money(r.gL) + ' · ' + esc(r.segL)), kv("Projected", money(r.gP) + ' · ' + esc(r.segP))]) +
      sec("Action logic", [kv("ABC", esc(r.abc)), kv("FMS", esc((r.fms || "—").replace(/^\d\.\s*/, ""))), kv("Purchase period", esc(r.quarter || "—")), kv("Channel", esc(r.channel || "—")), kv("MTD confirmed", int(r.mtd)), kv("Sell-through MTD", r.str == null ? "—" : pct(r.str * 100, 0))]) +
      sec("Sales", [kv("Avg 3D demand", (+r.avg3).toFixed(1)), kv("Avg 15D demand", (+r.avg15).toFixed(1)), kv("Confirmed last 15D", int(r.c15)), kv("Confirmed last 30D", int(r.c30))]) +
      sec("Inbound", [kv("Last inbound", dfmt(r.lpd)), kv("Days since last inbound", r.days == null ? "—" : int(r.days))]) + '</div></div>';
    document.body.appendChild(D); requestAnimationFrame(function () { D.classList.add("open"); });
    var close = function () { D.classList.remove("open"); setTimeout(function () { D.remove(); }, 200); };
    D.querySelector(".tw-dback").onclick = close; D.querySelector(".tw-dx").onclick = close;
  }
  /* ---------------------------------------------------------------- Overview card: Stock Snapshot (same numbers as the Inventory Aging tiles) */
  C.renderOverviewStock = function () {
    var host = $("ovStock"); if (!host) return;
    build();
    if (SC.empty) { host.innerHTML = '<div class="sc-note">Waiting for inventory data…</div>'; return; }
    var rows = SC.rows, inv = sum(rows, "inv"), unh = bsum(rows, 4);
    var items = [
      ["Inventory value", money(inv), int(sum(rows, "stock")) + " units on hand", ""],
      ["Days on hand", int(dohVal(rows)), "Good item stock value ÷ 15-day avg daily demand value — Damaged BOX not included (repacked pieces count once the warehouse marks them Good item)", ""],
      ["Unhealthy stock", pct(inv ? unh / inv * 100 : 0, 0), money(unh) + " at 12m+ aging", (inv && unh / inv > 0.3) ? "bad" : "warn"]
    ];
    host.innerHTML = items.map(function (t) { return '<div class="ov-stk' + (t[3] ? " ov-stk-" + t[3] : "") + '"><div><span>' + t[0] + '</span><small>' + t[2] + '</small></div><b>' + t[1] + '</b></div>'; }).join("");
  };

  /* ---------------------------------------------------------------- wiring */
  C.supplyConversionExport = convExport;
  C.invCategoryExport = catExport;
  var VIEWS = { scAging: ["viewScAging", renderAging], scSkus: ["viewScSkus", renderSkus], scActions: ["viewScActions", renderActions] };
  var current = null;
  function rerender() { build(); if (current && VIEWS[current]) { var h = $(VIEWS[current][0]); if (h && !h.classList.contains("hidden")) VIEWS[current][1](h); } }
  // وقت الداونلود (زرار Download CSV): نعرض كل الصفوف بدل الصفحة الحالية، وبعدها نرجع زي ما كان.
  var _savedSkuPage = 0;
  // v1.17.1: بنعيد البناء بس لو صفحة الـ Supply Chain هي المفتوحة (الداونلود من صفحة تانية مالوش دعوة بيها)
  function scOpen() { var h = current && VIEWS[current] && $(VIEWS[current][0]); return !!(h && !h.classList.contains("hidden")); }
  // v1.18.0 — Supply conversion follows the month filter: rebuild when it changes while this page is open
  document.addEventListener("change", function (e) { if (e.target && e.target.id === "monthSelect" && scOpen()) setTimeout(function () { try { rerender(); } catch (er) { } }, 0); });
  window.addEventListener("dash:export-start", function () { _savedSkuPage = SC.sk.page; SC.sk.page = 0; if (scOpen()) try { rerender(); } catch (e) { } });
  window.addEventListener("dash:export-end", function () { SC.sk.page = _savedSkuPage; if (scOpen()) try { rerender(); } catch (e) { } });
  function onClick(e) {
    var t = e.target;
    var c = t.closest("[data-sc-cat]"); if (c) { SC.cat = c.getAttribute("data-sc-cat"); rerender(); return; }
    var sg = t.closest("[data-sc-seg]"); if (sg) { SC.segMode = sg.getAttribute("data-sc-seg"); rerender(); return; }
    var a = t.closest("[data-sc-act]"); if (a) { SC.act = a.getAttribute("data-sc-act"); rerender(); return; }
    var pb = t.closest("#scConvPush"); if (pb) { e.stopPropagation(); convPush(pb); return; }
    var cb = t.closest("#scCatPush"); if (cb) { e.stopPropagation(); catPush(cb); return; }
    var s = t.closest("[data-sc-sku]"); if (s) { openSku(s.getAttribute("data-sc-sku")); return; }
    var b = t.closest("[data-sc]"); if (b) { var k = b.getAttribute("data-sc"); if (k === "prev") { SC.sk.page = Math.max(0, SC.sk.page - 1); drawSkuBody(); } else if (k === "next") { SC.sk.page++; drawSkuBody(); } return; }
    var th = t.closest("#scSkuTable th[data-k]"); if (th) { var key = th.getAttribute("data-k"); if (SC.sk.key === key) SC.sk.dir = SC.sk.dir === "asc" ? "desc" : "asc"; else { SC.sk.key = key; SC.sk.dir = "desc"; } SC.sk.page = 0; drawSkuBody(); }
  }
  function onInput(e) {
    var t = e.target; if (t.id === "scSkuQ") { SC.sk.q = t.value; SC.sk.page = 0; drawSkuBody(); return; }
    var k = t.getAttribute && t.getAttribute("data-sk"); if (!k) return;
    SC.sk[k] = t.type === "checkbox" ? t.checked : t.value; SC.sk.page = 0; drawSkuBody();
  }
  function setup() {
    Object.keys(VIEWS).forEach(function (name) {
      mkSection(VIEWS[name][0]);
      C.registerView(name, { sectionId: VIEWS[name][0], navId: ({ scAging: "navScAging", scSkus: "navScSkus", scActions: "navScActions" })[name], label: "", open: true, sub: "Inventory aging, stock health & actions", render: function (host) { current = name; build(); if (SC.empty) { host.innerHTML = '<div class="sc-note">Waiting for dashboard data (inventory, COGS, inbound and sales). It appears here as soon as the main data finishes loading.</div>'; return; } VIEWS[name][1](host); } });
      var h = $(VIEWS[name][0]); if (h) { h.addEventListener("click", onClick); h.addEventListener("input", onInput); h.addEventListener("change", onInput); }
    });
    boot();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", setup); else setup();
})();
