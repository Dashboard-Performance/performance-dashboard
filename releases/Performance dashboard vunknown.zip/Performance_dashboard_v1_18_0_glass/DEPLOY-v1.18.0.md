# v1.18.0-glass

> مبني على v1.17.6-glass اللي كانت على الجهاز. النسختين 17_7 و 17_8 ما كانوش متاحين، فاتعملوا من الأول حسب وصفهم (Glass + اللوجين + Usage Log). فمفيش ملف من 17_7 / 17_8 الأصلي هنا.

## الرفع (الترتيب مهم)
1. الـ Worker الأول، من فولدر `cloudflare-worker`:
   `npx.cmd wrangler deploy`
   لازم قبل الموقع، عشان فيه: مصدر Product Only الجديد + الـ Usage Log.
2. بعدين ارفع ملفات الموقع زي ما بتعمل دايماً.

الـ Usage Log مش محتاج حاجة في Cloudflare: بيستخدم قاعدة `taager-command-loop` (LOOP_DB) اللي متوصلة بالفعل، والجداول بتتعمل لوحدها أول ما يوصل أول تحديث، وأي حاجة أقدم من 6 شهور بتتمسح لوحدها.

## اللي جديد
**الشكل (17_7)**
- Glass و Liquid Glass بقوا شكل واحد اسمه **Glass**، والزرار فوق فيه اختيارين: Glass / Classic.
- Glass هو الافتراضي عند الكل (حتى اللي كان مختار Classic قبل كده، لأن مفتاح التخزين اتغير). ولو حد اختار Classic بعد كده بيتحفظ ليه هو بس.
- الشكل بيتطبق قبل أول رسمة للصفحة (مفيش لحظة بالشكل القديم).
- على الجهاز الضعيف، أو لو الجهاز اتعب، الشكل بيفضل Glass وبس كسر الضوء ولمعة الماوس بيتقفلوا على الجهاز ده.
- **اللوجين:** نفس خلفية الداشبورد + نورين متحركين، كارت إزاز تخين (حوافه بتكسر الضوء وبتلمع مع الماوس)، pill Login / Sign Up بتتزحلق، خانات إزاز بنور عند الكتابة، زرار Login كقطرة بلمعة (وهو بيحمّل اللمعة رايحة جاية)، الشمال بنص بيظهر سطر ورا سطر + لمعة على الكلمة الملونة (من غير أي كروت عائمة، عشان الشكل يفضل منظم)، وتنبيه **Caps Lock** تحت خانة الباسورد (Glass و Classic).
- **إصلاح Matches / Single:** تاب Marketplace فيه صفين تابات، والكود كان بيرسم pill للصف الأول بس، فالتاب النشط في الصف التاني كان نصه غامق على غامق. دلوقتي pill لكل صف.

**إصلاحات بعد أول تسليم**
- **الأرقام اللي فوق جدول Merchant Performance كانت بتعد من الصفر كل ثانية ونص.** السبب إن `refreshMerchantStats` (في tower.js، موجودة من قبل في 17_6) كانت بتمسح الكروت وتبنيها من جديد كل 1.5 ثانية، والـ Glass كان بيعتبرها أرقام جديدة فيعدّها من الأول. دلوقتي الرقم بيتحدّث مكانه، وأي كارت تاني بيتعاد بناؤه بنفس الشكل بياخد مكان القديم من غير عدّ. العدّ لسه بيحصل مرة واحدة لما الصفحة تتفتح أو الداتا توصل أول مرة. قياس: 6 إعادات عدّ في 9 ثواني ← صفر.
- **لاج التنقل بين التابات:** الـ View Transition (انتقال الصفحة كلها) كان بيعمل فريمز واقفة لحد 217ms عند كل تبديل. اتقفل افتراضياً، والصفحة الجديدة بتدخل بحركة السكشن العادية (نفس الاتجاه والتوقيت تقريباً، من غير ما القديمة تتحرك لبرّا). قياس في متصفح تجريبي: 10 فريمز فوق 100ms ← صفر، زي Classic بالظبط. لو عايز تجرّب الانتقال القديم: في الـ Console اكتب `localStorage.setItem("glVT","1")` وبعدين Reload.

**Over View (بعد التسليم)**
- الـ Overview كله (الكروت وPipeline Velocity وAvg Placed Pcs والـ Top Products والـ Category) بيتقرا من **Main (Matches)**، لأن فيه Bundle و Single مع بعض. Product Only فيه الـ Single SKUs بس.
- **Category Demand Breakdown اتشال.**
- صف جديد تحت: **Top Products** (أعلى 10 منتجات بالـ Delivered GMV ونسبة كل واحد) على الشمال تحت Sellthrough & Inbound، و **Category Contribution** (Pie Chart لنسبة كل كاتيجوري من الـ Delivered GMV) تحت Avg Placed Pcs. الـ GMV هنا هو Delivered GMV زي الكارت اللي فوق.

**نقل التابات**
- Segmentation Panel في Merchants بعد Merchant Targets.
- Sellthrough Rate Panel ثم Inventory & Inbound في Supply Chain بعد Inventory Aging.
- Admin Panel فضل فيه Forecast Model بس. التلاتة بقوا من غير باسورد. Forecast Model لوحده لسه بيطلب باسورد الـ Admin Panel.

**ترتيب الشكل**
- كارت **Supply conversion plan** في Control › Targets كان ضيق وبيقطع الجدول والخانات. بقى بعرض الصفحة زي KPIs و Segmentation plan، وخانات الـ PO والـ SKU اتوسعت.
- فحصت كل الصفحات بأربع مقاسات (1920 و1440 و1100 و820) ومفيش حاجة بتطلع برا كارتها. فيه 4 صفحات كانت بتطلع منها حاجات في الشاشة الصغيرة (820): Commercial Plan و CM3 Analyst / Products و CM3 Analyst و Allocation Locking (موجودة من 17_6). اتظبطوا بـ CSS للشاشات الصغيرة.

**Glass في الثيم الفاتح:** الخلفية كانت رمادي معكّر فالكروت كانت شكلها صندوق أبيض مسطّح. دلوقتي خلفية ألوان ناعمة بتبان من ورا الكروت الشفافة، وحافة بتلمع على الأطراف، وظل ملوّن خفيف. من غير backdrop-filter على الكروت (عشان السكرول يفضل خفيف). الثيم الغامق ما اتغيّرش.

**ML Forecast (جديد)** — Admin Panel › ML Forecast (جنب Forecast Model، ومن غير باسورد؛ الصلاحية من Users & Roles)
- موديل بيتعلم كل يوم ويتنبأ بـ Confirmed Pieces لكل Single SKU: **Locked** (فوركاست الشهر بيتقفل أول ما الشهر يبدأ وميتغيرش)، **Live** (الشهر اللي بعده، بيتحدّث كل يوم)، **Pace** (الشهر الجاري هيقفل على كام). والتاب بيعرض كمان دقة الـ backtest لكل سيجمنت و"المقفول vs اللي حصل".
- **المصدر:** تاب الـ history + كويري **Main** (الـ Matches، نفس الأعمدة)، مصدر واحد. أضفنا للموديل ميزات المرشنتات (عددهم وتركّزهم وهل أكبر مرشنت لسه شغال)، الـ Inbound اللي حصل فعلاً (من غير الشهر الجاي)، رصيد أول الشهر، السعر، وأخطاء الموديل في آخر شهرين، وتصحيح بيتعلّمه من أخطائه. **لازم ترفع الـ Worker تاني** (أضفنا Beginning Inventory للمصادر المسموحة للـ ML).
- الموديل نفسه في فولدر `ml-forecast/` (Python، بيتشغّل على GitHub Actions في ريبو taager-ml-forecast). الخطوات في `ml-forecast/README.md`: ارفع الـ Worker، ضيف `WORKER_URL` و`SERVICE_KEY` في GitHub Secrets، ابدل محتوى الريبو القديم، وشغّل الـ workflow مرة.
- الـ Worker فيه 3 endpoints جداد (`mlSource` و`mlPut` و`mlGet`) بيقروا مصادر محددة بس (Product Only و Main و Debundle Map و Products) بمفتاح الخدمة، ولينكات Metabase مبتخرجش من الـ Worker. المقفول write-once: الـ Worker بيرفض أي كتابة تانية لنفس الشهر.
- **اتجرّب:** 29 اختبار Worker جداد، و32 اختبار Python على داتا اصطناعية (منهم إن الموديل مبيشوفش المستقبل)، و17 فحص للتاب في متصفح. **ما اتجرّبش:** على الداتا الحقيقية ولا على Worker مرفوع. الدقة الحقيقية هتبان في أول تشغيل (الموديل القديم كان 38.6% مقابل 53.8% للـ Forecast Model).

**Usage Log (17_8)** — Control › Usage Log، للأدمن بس زي Activity Log (محتاج الـ admin key متحفظ في المتصفح)
- بيسجل مين فتح، امتى (بتوقيت القاهرة)، قعد قد إيه: **Open** (الداشبورد قدام الشاشة) و **Active** (ماوس/كيبورد/سكرول في آخر 30 ثانية)، أنهي تابات (باسم زي `Supply Chain › Planner DOH`) وقعد على كل تاب قد إيه، وأنهي ملفات نزّلها وكام صف.
- التاب المخفي أو الجهاز النايم ما بيتحسبوش. كل تاب مفتوح = جلسة. الإيميل بيتاخد من الـ token مش من المتصفح.
- فلاتر Today / Yesterday / Last 7 / Last 30، شخص معين، بحث، جدول الناس + أكتر التابات استخداماً + جدول الجلسات (الصف بيفتح الـ timeline)، Export CSV، وبيتحدّث كل دقيقة على Today.
- **أنصحك تعرّف الفريق إن استخدام الداشبورد بيتسجل.**

**مصادر البيانات**
- **صفحات ACM (ACM Performance و Target ACM): فضلت على Merchant Segmentation** (قرارك: دي تعريف الـ GMV المعتمد). يعني أرقام الأوردرات والـ Delivered GMV لكل ACM زي ما كانت في 17_6 بالظبط، ومفيش تغيير في الـ GMV. كويري Merchant Only مبقاش بيتطلب خالص (الكود موجود ومقفول بمفتاح واحد `ACM_USES_MERCHANT_ONLY` في أول `js/app.js` لو احتجته بعدين).
- الشهور الأقدم (يناير–أغسطس) في صفحات ACM بتتقرا من تاب gid 1433599782. ده تغيير عن 17_6 (كانت بتطلع أصفار للأوردرات في الشهور القديمة).
- **سبتمبر في صفحات ACM هيطلع فاضي زي 17_6:** كويري Segmentation فيها أكتوبر بس. لو عايز سبتمبر يظهر لازم نختار مصدر ليه (قولي).
- **القاعدة:** Product Only = Single SKUs بس (البندل متفكك على السنجلز). أي صفحة فيها Bundle و Single مع بعض بتقرا Main (Matches): Overview، Inventory & Products Performance، Commercial Plan، PPM Analyst / Products، أرقام الكاتيجوري في Targets (Commercial). أي صفحة Single بس بتقرا **Product Only**: PPM Analyst / Single، CM3 Analyst / Products، Planner DOH، صفحات الـ Supply Chain. الأوردر في Product Only بيتحسب مرة واحدة (Main كان بيحسبه على كل منتج جواه)، وقطع البندل بتتحسب على السنجلز، فالإجماليات مش لازم تتطابق. الكاتيجوري مش في الكويري، فبتتاخد من نفس الـ SKU في Main / Products Info.
- لسه على Main (مش اتنقلوا): كل صفحات الـ Match، صفحات التجار، Purchase Plan، Weekly Inventory، Forecast Model، Inventory، Overview الإجمالي.
- **Control › Settings:** كارت "Product & category pages — data source": اختيار Product Only / Main (محفوظ على المتصفح) + جدول مقارنة Main مقابل Product Only لكل شهر (القطع، الأوردرات، GMV، CM3، PPM) عشان تقارن الأرقام بنفسك.
- لو أي مصدر جديد ما اتحمّلش (أو الـ Worker لسه ما اترفعش)، الصفحات بترجع لوحدها للمصدر القديم.

## الفروق في الأرقام اللي لازم تعرفها
- **Delivered GMV للـ ACM: مفيش تغيير** (Segmentation). لكن لاحظ إن ده أعلى من Merchant Only (اللي بيطابق Main) بحوالي 8% في أكتوبر: الفرق في قيمة الـ GMV لـ 96 تاجر من 665 (الأوردرات والقطع متطابقة)، وأول 10 تجار بيمثلوا 64% منه. يعني رقم الـ ACM في صفحات ACM مش هيطابق رقم الـ Delivered GMV في صفحات Main / الـ CM3 %.
- أرقام الأوردرات في صفحات المنتج هتقل عن Main (الأوردر بيتحسب مرة واحدة). القطع والـ GMV المفروض تتطابق: قارنهم من كارت Settings.

## اتجرّب إزاي
- اختبارات الـ Worker: 18 + 25 + 109 + 19 + 9 الموجودة + 26 جداد للـ Usage Log، كلها نجحت.
- صفحات ACM بعد الرجوع لـ Segmentation: بالدالة الحقيقية نفس مخرجات 17_6 بالظبط (أكتوبر، سبتمبر، All Months)، وأكتوبر بيطلع 2700 (Segmentation) مش 2500 (Merchant Only) في الاختبار؛ والصفحة بتفتح من غير أخطاء ومبتطلبش Merchant Only. التاجر 1160154 مش في Segmentation، وفي Merchant Only ACM بتاعه فاضي (أكتوبر: 103 أوردر، 8 اتسلموا، GMV 1,522)، فمفيش أثر على أرقام الـ ACM.
- صفحات الـ Single على Product Only بالدوال الحقيقية: نفس مخرجات Main على داتا متكافئة (PPM Single، CM3 Products، Planner DOH). عيّنة حقيقية من Product Only (SE0105، 1 سبتمبر) اتجمعت صح.
- Glass / Classic / الافتراضي / الجهاز الضعيف والقوي، اللوجين (غامق وفاتح و Classic، الـ pill، الـ Caps Lock، كسر الضوء)، إصلاح Matches / Single، و Usage Log (تتبّع، Worker بداتا مزيفة، الصفحة، Admin بس) — كلهم اتجرّبوا في متصفح.
- **ما اتجرّبش:** مقارنة Product Only بـ Main على الداتا الحقيقية كاملة (المتصفح كان مفصول)، فاستخدم كارت Settings. ولا Usage Log على Worker مرفوع فعلاً.

## Forecast Model Merchant + أسماء التابات في الكود
- **Forecast Model Merchant** (Admin Panel، بنفس باسوورد Forecast Model): نفس صفحة Forecast Model ونفس الحسابات بالظبط (الـ Behaviors، الـ Size segments A/B/C، الـ TSB وقواعد المعدل الأخير، الـ error-correction، الـ ranges، الـ backtests والـ accuracy)، بس الوحدة هي الـ **Merchant** مش الـ SKU. الديماند = الـ Confirmed pieces اليومية للتاجر (as sold) من تاب الـ History (مجمّعة بالتاجر على Google) + صفوف Matches، واليوم الموجود في الاتنين بيتحسب مرة من Matches. اسم التاجر والـ ACM من Matches. مفيش price-change adjustment ولا stock ceiling ولا أعمدة Stock / Repack / Inbound (دول مفهومين على مستوى الـ SKU بس). الـ segments (A ≥ 100 / B 30–99 / C < 30 قطعة في الشهر) هي نفس حدود الـ SKU.
- التابين بيحتفظوا بداتا وفلاتر منفصلة؛ بتتحمّل الداتا أول مرة تفتح كل تاب، وبعدها الرجوع بين التابين فوري.
- الاسم في الكود بقى زي الاسم الظاهر: **Commercial Plan** = `commercialPlan` / `navCommercialPlan` / `viewCommercialPlan` / `computeCommercialPlan` / `prepareCommercialPlanData` (كان Commercial Debundlized). الأدوار المحفوظة واللينكات القديمة (`commercial-debundlized.html` واسم التاب القديم) بتتحول تلقائي. قاعدة التسمية مكتوبة في أول `js/tower.js` مع قائمة التابات القديمة اللي اسمها الداخلي لسه مختلف.
- الـ Worker: تعديل صغير في `cloudflare-worker/loop.js` (قائمة تابات فريق Commercial فيها الاسم الجديد). ارفعه مع أي رفع جاي، مش مستعجل.

## ML Forecast v2.1 + نقطة الأفاتار
- **ML (GitHub):** اتضافت وصفة الـ Forecast Model كمرشح (`dash`) ومعاها `blend` (Ensemble + الوصفة 50/50) و`blend_gbm`. على الداتا الحقيقية (أبريل–سبتمبر، تنبؤ آخر الشهر): الدقة الكلية 43.2% ← 47.9%، وA من 48.4% ← 53.8%. بالـ walk-forward (يوليو–سبتمبر): 43.0% ← 49.2%، وA 48.6% ← 56.0%. تاب ML Forecast بيعرض الأعمدة الجديدة. لازم ترفع فولدر `taager-ml-forecast_v4` على الـ repo عشان الـ run الجاي يستخدمها.
- **سقف الستوك اتشال من Forecast Model:** كان بيحسب الإنبوند اللي بيوصل جوه الشهر المتنبأ بيه (مش معروف وقت التنبؤ) وبيطبّق على الـ backtest والشهر الجاري بس، مش على رقم الشهر الجاي. بعد الشيل، على الداتا الحقيقية (أبريل–سبتمبر، تشغيل الـ Forecast Model الحقيقي): الدقة الكلية 53.6% ← **47.2%**، وA 57.6% ← **50.5%**، وB وC ما اتغيروش، ورقم الشهر الجاي ثابت تقريباً (155,091 ← 155,137 قطعة). يعني الأرقام اللي فاتت كانت مبالغ فيها، والجديدة هي اللي الرقم الحي بيحققها فعلاً. بتتحكم فيه `FC_STOCK_CEILING_ON` في `js/app.js`.
- **نقطة الأفاتار:** خضراء لما آخر Refresh خلص وكل المصادر اتحدثت (`Live — updated` / `Up to date`)، وصفراء طول ما فيه حاجة ما اتعملهاش Refresh (بيحمّل، بيعمل Refresh، أرقام من الكاش، شيت ⚠ not refreshed، أو sync فشل وبيعيد المحاولة). الـ tooltip بيقول السبب.
- **Planner DOH — Only placed yesterday:** لو الداتا لسه ما وصلتش لأمس (أول يوم في الشهر الجديد أو أي تأخير في اللود اليومي) كان الفلتر بيرجّع صفر SKUs. دلوقتي لو مفيش داتا لأمس بيعتبر آخر يوم فيه داتا هو "أمس" (والـ Avg 3D والـ CR window بيتحركوا معاه)، وبيكتب جنب التاريخ "(latest day with data — … not loaded yet)". لما الداتا توصل بيرجع لأمس الحقيقي لوحده.
- **Incentive Merchants — أرقام أكتوبر:** التاب بتفتح دلوقتي على **October 2026** وبتاخد أرقامه النهائية من تاب `2125522926` في الـ Google Sheet (نفس أعمدة كويري Merchant Segmentation، 686 تاجر، العمود CONFIRMED). كويري Segmentation بترجّع الشهر الحالي بس، فالشهور المقفولة بتتقرا من تابات في `MERCHANT_SEG_ARCHIVE_GIDS` (أول `js/app.js`). لو نفس (تاجر + شهر) في الاتنين بيتاخد تاب الشهر المقفول. الشهر المقفول: Run Rate = الفعلي. لما نوفمبر يتقفل: ضيف GID تابه في `MERCHANT_SEG_ARCHIVE_GIDS` وغيّر `INCENTIVE_DEFAULT_MONTH` (أو خليها "" لو عايزها تفتح على الشهر الحالي). الباقي (جدول Merchant Segmentation & Projections) لسه على الكويري بس.
- **أول الشهر — الـ Worker كان بيفضل يبعت نسخة قديمة (لازم رفع Worker):** حارس "آخر نسخة سليمة" كان بيعتبر خروج الشهر القديم من نافذة الكويري (Main و Product Only بيرجعوا "الشهر اللي فات + الشهر الحالي") انهيار في الداتا (rows fell 46%)، فكان بيبعت نسخة قديمة لمدة 12 ساعة. الأثر الفعلي يوم 1 نوفمبر: نسخة Main و Product Only و Segmentation كانت من مساء 31 أكتوبر، وآخر يوم (31) كان لسه ناقص — وده سبب إن Pipeline Velocity بتعرض 31 بقيمة أقل. الإصلاح: المقارنة بالإجمالي بقت على الشهور اللي لسه في نافذة الإجابة الجديدة بس، وكويري Merchant Segmentation (بترجع الشهر الحالي بس) بتقبل الإجابة الأصغر لما الشهر يتغير (بتوقيت القاهرة). أي انهيار حقيقي (شهر بيفقد أكتر من 10% من صفوفه) لسه بيتمسك زي ما كان، وكمان Beginning Inventory (500 صف ← 1) لسه متمسك. الملف: `cloudflare-worker/worker.js`.
- **Planner DOH — Send to sheet (محتاج تحديث Apps Script):** الزرار كان بيفشل برسالة "Lock timeout: another process was holding the lock for too long" (بالفرنساوي عندك: "Expiration de la demande de verrouillage…"). الكتابة كانت بتستنى الـ **script lock** 30 ثانية، وده نفسه اللي بتمسكه عمليات تانية لدقايق (نشر Analyst / Single daily وحفظ الفيدباك…). دلوقتي الكتابة بتاخد **user lock** (قفل منفصل، لسه بيمنع كتابتين Planner DOH في نفس الوقت) وبتستنى 45 ثانية، ولو فيه كتابة تانية لسه شغالة بتقول "A previous Planner DOH write is still running — wait a minute and press Send to sheet again". الملف: `backend/Code.gs` ← الدالة `writePlannerDoh_`. الرفع: افتح مشروع الـ Apps Script، الصق الـ Code.gs الجديد، Deploy ← Manage deployments ← ✏️ ← Version: New version ← Deploy (نفس الرابط).
- **شريط الـ Sync (Live System Sync):** سطر "Last sync: <الوقت>" كان بيتكتب بعد أي تحديث للشاشة (تغيير فلتر…) ويمسح تحذير ⚠ (مثلاً "⚠ Beginning Inventory — cached from …") فكان بيظهر كإن كله اتعمله Refresh وهو لأ. دلوقتي التحذير مش بيتمسح، وحالة الـ Refresh (للنقطة الخضرا/الصفرا) بتتسجل لوحدها ومش بتتغير بكتابة وقت الشاشة. الأخضر = آخر Refresh خلص وكل المصادر اتحدثت.
- **Planner DOH — Send to sheet (تحديث تاني، لازم Code.gs من جديد):** الرسالة "Server returned an invalid response (HTTP 524)" معناها إن الـ Apps Script اتأخر أكتر من 100 ثانية في الكتابة (الـ Worker بيقطع الانتظار، لكن الكتابة غالباً بتكمّل). `writePlannerDoh_` بقت بتكتب كل حاجة في **عملية واحدة** (بدل مسح ثم كتابة) وماتعيدش تظبيط الفورمات لو موجودة، لأن فورمولات فريق التخطيط في O.. بتتحسب من جديد مع كل تغيير في الأعمدة A–N. والداشبورد بقت لو جاتلها 524 تكتب "Sent — still writing, check the sheet in ~2 min" بدل رسالة خطأ.
- **تارجتس الشهر:** Targets Upload ← Target month = الشهر ← "Import all from Google Sheet" بتحفظ التارجتس الحالية تحت الشهر ده ثابتة (`<type>.<YYYY-MM>` في الـ Worker). الفلتر على الشهر بيقرا تارجتس الشهر ده بس، والشهر اللي ما اترفعش ليه حاجة بيرجع للـ upload القديم ثم الـ Google Sheet.
