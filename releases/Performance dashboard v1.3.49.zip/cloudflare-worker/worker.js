/* ==========================================================================
   Performance Dashboard — Sync Cache Worker (Cloudflare Workers)
   --------------------------------------------------------------------------
   الغرض: يقف كطبقة كاش وسيطة سريعة ومجانية بين كل اليوزرز وبين Apps Script،
   بس لطلبات القراءة الكتيرة (action=getLastSync و action=getLastSyncMeta).

   ليه محتاجينه: كل يوزر فاتح/بيعمل رفرش للداشبورد كان بيضرب Apps Script
   مباشرة، وApps Script عنده حد أقصى لعدد التنفيذات المتزامنة — لما عدد
   الناس اللي بيفتحوا/يعملوا رفرش في نفس اللحظة يزيد، بعض الطلبات كانت
   بتفشل (404 من مسار script.googleusercontent.com/macros/echo بتاع جوجل).

   إزاي بيحل المشكلة: الـ Worker ده بيسحب نسخة واحدة بس من Apps Script كل
   5 دقايق (عن طريق Cron Trigger)، ويخزّنها في Cloudflare KV. أي طلب من أي
   يوزر بيتخدم فورًا من الـ KV cache ده — من غير ما يضرب Apps Script خالص.
   يعني 1000 يوزر فاتحين في نفس اللحظة = 1000 قراءة KV خفيفة جدًا (مجانية
   لحد 100,000 قراءة/يوم على Cloudflare)، بدل 1000 تنفيذ متزامن على
   Apps Script.

   لو الـ Cron فشل مرة (Apps Script كان واقف وقتها)، الـ Worker بيرجع آخر
   نسخة كانت متخزنة قبل كده بدل ما يرجع فشل لليوزر — تدهور تدريجي، مش انهيار
   فجائي.

   إعداد النشر (Deploy) — مرة واحدة بس:
   1) لو معندكش حساب Cloudflare، اعمل واحد مجاني على https://dash.cloudflare.com
   2) ثبّت الأداة المحلية (Wrangler) — تحتاج Node.js مثبت عندك:
        npm install -g wrangler
   3) من جوه الفولدر ده (cloudflare-worker/) في الترمينال:
        wrangler login
        wrangler kv namespace create "SYNC_CACHE"
      الأمر ده هيطلعلك id — انسخه وحطه مكان "REPLACE_WITH_YOUR_KV_NAMESPACE_ID"
      في ملف wrangler.toml المجاور لهذا الملف.
   4) انشر الـ Worker:
        wrangler deploy
      هيديك رابط زي: https://performance-dashboard-sync-cache.<your-subdomain>.workers.dev
   5) انسخ الرابط ده وحطه في js/app.js مكان قيمة SYNC_CDN_URL (فاضية حاليًا)،
      وارفع app.js المحدث على Vercel.
   ========================================================================== */

// تاب "Confirmed by Day" (Weekly Inventory & Inbound) — بيتقرا هنا مباشرة
// من Google Sheets (gviz) بدل ما يعدي على Apps Script خالص، عشان يبقى
// مستقل تمامًا عن أي مشكلة Deploy في الباك اند (اللي واجهناها فعليًا).
// نفس الـ Cron كل 5 دقايق (تحت في scheduled()) بيحدّثه، وأي طلب من أي
// يوزر بيتخدم من الـ KV Cache ده فورًا.
const CACHE_KEY_CONFIRMED_BY_DAY = "confirmed_by_day_v1";
const CONFIRMED_BY_DAY_GID = "964398740";
// بطلب صريح ("ليه مش بيوريني إنه فشل؟"): زي CACHE_KEY_MAIN_ERROR تحت بالظبط —
// لو الـ cron تاع الشيت ده فشل، كان بيتسجل بس في console.error (مش ظاهر في
// "Worker Sync Status" خالص، فكان بيبان زي إن مفيش أي مشكلة، بس التوقيت
// بيقدّم من غير سبب واضح). دلوقتي بيتسجل هنا وبيتبعت مع الرد عشان يظهر.
const CACHE_KEY_CONFIRMED_BY_DAY_ERROR = "confirmed_by_day_error_v1";
// v1.1.51: بصمة رخيصة لآخر نسخة اتكتبت فعليًا في CACHE_KEY_CONFIRMED_BY_DAY —
// راجع الكومنت الكبير فوق refreshConfirmedByDayCache تحت لشرح ليه محتاجينها.
const CACHE_KEY_CONFIRMED_BY_DAY_META = "confirmed_by_day_meta_v1";
// تاب "Incentive Merchants" (Incentives Tracker) — نفس فكرة Confirmed by Day
// فوق بالظبط: بيتقرا هنا مباشرة من Google Sheets (gviz)، مستقل تمامًا عن
// Apps Script، عشان نتجنب نفس مشكلة الـ Deploy اللي واجهناها مع GID
// 964398740 قبل كده.
const CACHE_KEY_INCENTIVE_MERCHANTS = "incentive_merchants_v1";
const INCENTIVE_MERCHANTS_GID = "1548963809";
// نفس فكرة CACHE_KEY_CONFIRMED_BY_DAY_ERROR فوق.
const CACHE_KEY_INCENTIVE_MERCHANTS_ERROR = "incentive_merchants_error_v1";
// نفس فكرة CACHE_KEY_CONFIRMED_BY_DAY_META فوق.
const CACHE_KEY_INCENTIVE_MERCHANTS_META = "incentive_merchants_meta_v1";
// شيت الـ Main (المصدر الأساسي لكل الداشبورد تقريبًا) — بيتقرا هنا مباشرة
// من Google Sheets (gviz) بدل ما يعتمد بس على نسخة Apps Script المجمّعة
// (getLastSync). السبب (بطلب صريح): لو اليوزر بيعمل تعديل/لصق داتا في
// الشيت وقت ما الـ Cron بتاع Apps Script بيشتغل، ممكن ياخد لقطة نص-متغيرة.
// هنا بنعمل "stability check" مستقل: كل Cron tick (كل 5 دقايق) بنسحب نسخة
// جديدة ونقارن بصمتها ببصمة آخر تشغيلة (مش نفس التشغيلة — بين تشغيلتين
// متتاليتين، يعني فاصل 5 دقايق حقيقي)، ومنعتبرش الشيت "مستقر" ونستخدمه إلا
// لو البصمتين متطابقتين. لو لسه بيتغيّر، بنفضل نخدّم آخر نسخة مستقرة معروفة
// بدل ما ننشر نسخة نص-متغيرة. البصمة نفسها (عدد الصفوف + أطوال أول/آخر صف)
// زي fetchSheetsPayloadStable_/sheetFingerprint_ في backend/Code.gs بالظبط.
const CACHE_KEY_MAIN = "main_sheet_v1";              // آخر نسخة "مستقرة" مؤكدة — دي اللي بتتخدم لليوزرز
const CACHE_KEY_MAIN_CANDIDATE = "main_sheet_candidate_v1"; // آخر قراءة خام (لمقارنة التشغيلة الجاية بيها)
// v1.1.34 (تصحيح): {stable, fetchedAt, rowCount} خفيفة جدًا، منفصلة تمامًا
// عن CACHE_KEY_MAIN الضخم — بتتحدث كل ما CACHE_KEY_MAIN يتحدث. الهدف إن
// handleGetMainMeta/getMainMeta ميحتاجش يعمل JSON.parse لجدول ممكن يكون
// عشرات الـ MB (33 ألف صف) بس عشان يجيب عدد الصفوف — ده كان بالظبط سبب
// "Failed to fetch": الـ CPU limit بتاع الـ Worker كان بيتعدى والتنفيذ
// بيتقفل فجأة من غير ما يرجع رد خالص (مش حتى إيرور JSON عادي).
const CACHE_KEY_MAIN_META = "main_sheet_meta_v1";
// v1.1.35: نفس الإيميل بالظبط المستخدم كـ PRESENCE_ADMIN_EMAIL في js/auth.js
// وbackend/Code.gs — بوابة بسيطة (مش أمان حقيقي، بس كافية هنا لأن أقصى ضرر
// ممكن يحصل هو حد يعمل refresh قبل معاده بشوية) لأكشن forceRefresh تحت.
const MANAGER_EMAIL = "youssef.hanafy@taager.com";
const OWNER_EMAILS = ["youssef.hanafy@taager.com", "somaya.youssef@taager.com"];
function isOwnerEmail(e) { return OWNER_EMAILS.indexOf(String(e || "").trim().toLowerCase()) !== -1; }
// v1.1.33: لو refreshMainCache فشلت جوه scheduled() (مثلاً الشيت كبير جدًا
// وتعدى حد الـ KV، أو gviz رجع رد غريب)، الفشل كان بيتسجل بس في console.error
// (مش شايفينه إلا لو شغّلت wrangler tail لحظتها). دلوقتي بنسجله هنا كمان عشان
// يظهر في "Worker Sync Status" جوه الداشبورد من غير ما تحتاج CLI خالص.
const CACHE_KEY_MAIN_ERROR = "main_sheet_error_v1";
const MAIN_GID = "2099497960";

// v1.1.46: كل الـ 21 شيت الباقيين (Inventory وكل حاجة تانية غير Main/
// Confirmed by Day/Incentive Merchants) بقوا بيتقروا من Apps Script بس
// (backend/Code.gs: LAST_SYNC_GIDS + runScheduledSync)، مش من الـ Worker
// خالص. السبب: Cloudflare Observability أثبتت إن الـ CPU budget الحقيقي
// لخطة الـ Worker (Free) حوالي 10ms بس لكل تشغيلة — أي شغل حقيقي (fetch +
// JSON.parse + fingerprint) لأي شيت كان بيعدّيه ويخلي scheduled() يفشل
// (exceededCpu) في كل تشغيلة تقريبًا، حتى مع batch صغير (3 شيت بس). ده كان
// السبب الحقيقي وراء إن "General Sync — Worker" كان دايمًا "عالق"/قديم في
// مودال "Worker Sync Status".
// Apps Script (Time-driven trigger، مش Cloudflare Worker) معندهوش نفس حد
// الـ CPU-ms ده (بيتحدد بالوقت الكلي للتنفيذة، دقايق مش milliseconds)،
// فبقى هو المصدر الوحيد لكل الـ 21 شيت — بيقراهم كلهم مع بعض في تنفيذة
// واحدة كل 5 دقايق (fetchSheetsPayloadStable_)، يعني كل الشيتات دي بتتحدث
// مع بعض فعلاً في نفس الوقت، مش متقسمة/متأخرة عن بعض زي لما كانت متقسمة
// بين مصدرين. راجع تعليق LAST_SYNC_GIDS جوه backend/Code.gs.
// الـ Worker فضل مسؤول بس عن Main (شيت واحد كبير، قراءة خفيفة نسبيًا لكل
// طلب) وConfirmed by Day وIncentive Merchants — دول مش جزء من "General
// Sync" ومعندهمش نفس المشكلة.

// v1.1.40: نفس فكرة PRESENCE_ADMIN_EMAIL/heartbeat بتاعة js/auth.js وbackend/
// Code.gs، بس اتنقلت هنا بالكامل — بيانات "مين أونلاين" مؤقتة بطبيعتها
// (مش سجل دائم محتاج يتخزن في شيت)، فمفيش داعي تعدي على Apps Script أصلاً
// عشانها. بنخزنها في نفس الـ KV.
const CACHE_KEY_PRESENCE = "presence_map_v1";
const PRESENCE_ONLINE_WINDOW_MS = 90 * 1000;
const PRESENCE_STALE_MS = 15 * 60 * 1000;
const ALLOWED_EMAIL_DOMAIN = "taager.com";

// Metabase public-link CORS proxy: pure streaming passthrough (no body parsing -> negligible CPU).
// Only metabase.taager.com public question/card endpoints are allowed.
async function handleMetabaseProxy(url) {
  const target = url.searchParams.get("url") || "";
  let t;
  try { t = new URL(target); } catch (e) { return jsonResponse({ success: false, message: "bad url" }, 400); }
  const okPath = /^\/(public\/question\/|api\/public\/card\/)[0-9a-f-]{36}(\.json|\/query\/(json|csv))?$/i.test(t.pathname);
  if (t.protocol !== "https:" || t.hostname !== "metabase.taager.com" || !okPath) {
    return jsonResponse({ success: false, message: "url not allowed" }, 403);
  }
  const r = await fetch(t.toString(), { redirect: "follow" });
  const h = corsHeaders();
  h["Content-Type"] = r.headers.get("Content-Type") || "application/octet-stream";
  h["Cache-Control"] = "no-store";
  return new Response(r.body, { status: r.status, headers: h });
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Release-Secret",
    "Access-Control-Expose-Headers": "Content-Disposition",
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  };
}

function jsonResponse(obj, status) {
  return new Response(JSON.stringify(obj), { status: status || 200, headers: corsHeaders() });
}

// بيقرا شيت واحد مباشرة من Google Sheets (gviz) — نفس بالظبط الطريقة
// القديمة اللي كانت مستخدمة قبل ما نعمل الباك اند المركزي، بس هنا شغالة
// من على سيرفر Cloudflare (مش من متصفح كل يوزر لوحده). النتيجة بترجع بنفس
// شكل { table: { cols, rows } } اللي parseConfirmedByDaySheet() في app.js
// متعودة عليه، فمفيش أي تغيير مطلوب في منطق الـ parsing.
async function fetchGvizSheet(sheetId, gid) {
  const url = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?gid=${encodeURIComponent(gid)}&tqx=out:json`;
  const res = await fetch(url, { cf: { cacheTtl: 0 } });
  if (!res.ok) throw new Error(`gviz responded with status ${res.status}`);
  const text = await res.text();
  const match = text.match(/setResponse\(([\s\S]*)\);?\s*$/);
  if (!match) throw new Error("Unexpected gviz response shape (sheet/gid not public or wrong id?)");
  // gviz بيرجّع Date(y,m,d,...) حرفي مش JSON صالح. الباك اند (Code.gs) بيحلها
  // بـ eval() لأن Apps Script بيسمح بيه — لكن Cloudflare Workers بيمنع
  // eval()/new Function() تمامًا افتراضيًا ("Code generation from strings
  // disallowed"). فبدل eval بنستبدل أي Date(...) جايه فعلاً كـ *قيمة* (يعني
  // بعد "v": مباشرة) بنص JSON صالح — من غير ما نحتاج نفكه فعليًا لتاريخ
  // حقيقي، لأننا أصلاً مش بنستخدم قيمته (الفرونت اند بيقرا الـ "f" المنسّق
  // بس، مش "v"). العلامة "v": شرط عشان منستبدلش أي نص عادي جوه string لو
  // حصل واحتوى على كلمة "Date(" بالصدفة (زي اسم منتج فيه أقواس).
  const jsonSafeText = match[1].replace(/"v":Date\(([^)]*)\)/g, (m, inner) => '"v":"Date(' + inner + ')"');
  let parsed;
  try {
    parsed = JSON.parse(jsonSafeText);
  } catch (parseErr) {
    // نطلع سياق حوالين مكان الخطأ بالظبط عشان نقدر نشخص أي مشكلة تانية في
    // شكل الداتا من غير ما نحتاج نجيب الـ raw response يدويًا.
    const posMatch = /position (\d+)/.exec(parseErr.message);
    const pos = posMatch ? parseInt(posMatch[1], 10) : null;
    const snippet = pos !== null ? jsonSafeText.slice(Math.max(0, pos - 120), pos + 120) : "";
    throw new Error(
      "Failed to parse gviz JSON for gid " + gid + ": " + parseErr.message +
      (snippet ? " | context: ..." + snippet + "..." : "")
    );
  }
  if (parsed && parsed.status === "error") throw new Error("gviz returned status=error for gid " + gid);
  return parsed;
}

// v1.1.48: نسخة "خام" من fetchGvizSheet فوق — بترجع نص الـ JSON بعد فك
// setResponse() وتصحيح Date(...) بس، من غير JSON.parse خالص. السبب: اكتشفنا
// (Observability) إن الـ exceededCpu مكنش بس بسبب الـ 21 general-mirror
// (اتحلت في v1.1.46) — كان لسه بيحصل لـ Main (35 ألف صف) وConfirmed by Day
// (~640KB) لوحدهم، لأن JSON.parse لجدول بالحجم ده بياخد CPU حقيقي (بعكس
// fetch() نفسه، اللي وقت الانتظار بتاعه مبيتحسبش على budget الـ Worker
// خالص). فبدل ما نحوّل النص لـ object ضخم في الميموري بس عشان نخزّنه تاني
// كـ نص (JSON.stringify)، بنفضل نص طول الوقت: تخزين، فحص خطأ، بصمة تغيّر،
// وحتى تقدير عدد الصفوف — كل ده بعمليات نص رخيصة (indexOf/regex/slice) بدل
// تحويل كامل للبيانات.
async function fetchGvizSheetRaw(sheetId, gid) {
  const url = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?gid=${encodeURIComponent(gid)}&tqx=out:json`;
  const res = await fetch(url, { cf: { cacheTtl: 0 } });
  if (!res.ok) throw new Error(`gviz responded with status ${res.status}`);
  const text = await res.text();
  const match = text.match(/setResponse\(([\s\S]*)\);?\s*$/);
  if (!match) throw new Error("Unexpected gviz response shape (sheet/gid not public or wrong id?)");
  const jsonSafeText = match[1].replace(/"v":Date\(([^)]*)\)/g, (m, inner) => '"v":"Date(' + inner + ')"');
  // فحص خفيف للخطأ — "status":"error" بيظهر قريب من أول النص دايمًا في رد
  // gviz، فبنفحص أول 300 حرف بس (indexOf رخيص) بدل JSON.parse كامل.
  if (jsonSafeText.slice(0, 300).indexOf('"status":"error"') !== -1) {
    throw new Error("gviz returned status=error for gid " + gid);
  }
  return jsonSafeText;
}

// بيدخل حقل جديد (key:valueJsonText) جوه نص JSON object موجود بالفعل — بإضافة
// ",\"key\":value" قبل الـ "}" الأخيرة مباشرة. عملية نصية رخيصة جدًا (slice +
// concat) بدل ما نعمل JSON.parse لكل النص (ممكن يبقى مئات الـ KB) بس عشان
// نضيف حقل واحد صغير زي lastError.
function appendJsonField(jsonText, key, valueJsonText) {
  const trimmed = jsonText.replace(/\s+$/, "");
  if (trimmed.charAt(trimmed.length - 1) !== "}") return jsonText;
  return trimmed.slice(0, -1) + ',"' + key + '":' + valueJsonText + "}";
}

// تقدير رخيص لعدد الصفوف من النص الخام مباشرة (من غير parsing) — كل صف في
// رد gviz شكله {"c":[...]}، وده مفتاح مش موجود في تعريفات الأعمدة (cols)،
// فعدّ عدد مرات ظهور "c":[ بيديني عدد الصفوف الفعلي تقريبًا.
function estimateRowCount(rawText) {
  const m = rawText.match(/"c":\[/g);
  return m ? m.length : null;
}

// بصمة رخيصة جدًا مبنية على النص الخام مباشرة (من غير أي parsing) — بتاخد
// طول النص + عينات صغيرة (120 حرف) من 6 نقاط موزعة على طول النص. كافية
// عمليًا لاكتشاف أي تعديل حقيقي في الشيت (أي تغيير في أي مكان هيغيّر الطول
// أو يقع جوه واحدة من العينات على الأقل في أغلب الحالات)، بنفس فكرة
// sheetFingerprint القديمة (المبنية على object متحلل) بس من غير تكلفة الـ
// parsing خالص.
function rawTextFingerprint(text) {
  if (!text) return null;
  const len = text.length;
  const windowLen = 120;
  const numSamples = 6;
  let out = String(len);
  for (let i = 0; i < numSamples; i++) {
    const pos = Math.floor((len * i) / numSamples);
    out += "|" + text.slice(pos, pos + windowLen);
  }
  return out;
}

// v1.1.51: مشكلة اتكشفت بعد ما رجّعنا الـ Cron لدقيقة واحدة (v1.1.47) +
// حلينا الـ exceededCpu (v1.1.48): Cloudflare KV عندها حد 1,000 كتابة
// (write) في اليوم بس على خطة Free. كل تشغيلة cron ناجحة كانت بتكتب في KV
// حتى لو الداتا نفسها **متغيّرتش خالص** من آخر مرة — يعني شيت مستقر وهادي
// كان لسه بيتكتب في KV كل دقيقة (1,440 كتابة/يوم بس من الشيت ده، والتلاتة
// شيتات مع بعض كانوا بيعدوا الـ 1,000 بسرعة جدًا في نص اليوم). لما الـ
// quota تخلص، أي كتابة تانية في KV (حتى heartbeat بتاع "مين أونلاين") كانت
// بتفشل بـ exception (Error 1101) — ده سبب ظهور "Online: 0" رغم إن
// اليوزرز فاتحين فعلاً. وكمان كل تحديث (حتى لو نفس الداتا بالظبط) كان بيغيّر
// "fetchedAt"، فالفرونت اند (mainMetaPollTick) كان بيعتبرها "نسخة جديدة"
// ويعمل تحميل كامل لجدول الـ Main (25+ ميجا بايت) وparsing كامل على الـ
// main thread — وده السبب الحقيقي وراء "بيتجمد كل شوية": كان بيحصل كل
// دقيقة أو اتنين تقريبًا حتى لو مفيش أي تغيير حقيقي في الداتا.
//
// الحل: بصمة "آخر نسخة اتكتبت فعليًا" (META) منفصلة عن أي حاجة بنقارن بيها
// الاستقرار — لو الداتا الجديدة طابقت آخر نسخة مكتوبة بالفعل، منعملش أي
// كتابة KV خالص (صفر) ونرجع نفس الـ fetchedAt القديم زي ما هو. الكتابة
// بتحصل بس أول مرة أو لما الداتا فعلاً تتغيّر — يعني في يوم عادي (الداتا
// بتتغيّر كذا مرة بس مش كل دقيقة) هتبقى كتابات KV قليلة جدًا، وfetchedAt
// هيفضل ثابت (بمعنى صحيح: "آخر تحديث حقيقي") لحد ما حاجة تتغيّر فعلاً —
// وده كمان بيوقف التحميل الكامل المتكرر بتاع الفرونت اند تلقائيًا.
async function refreshConfirmedByDayCache(env, forceWrite) {
  const sheetId = env.SHEET_ID;
  if (!sheetId) throw new Error("SHEET_ID env var is not configured in wrangler.toml");
  const rawTable = await fetchGvizSheetRaw(sheetId, CONFIRMED_BY_DAY_GID);
  const fp = rawTextFingerprint(rawTable);
  const nowIso = new Date().toISOString();
  const metaRaw = await env.SYNC_CACHE.get(CACHE_KEY_CONFIRMED_BY_DAY_META);
  const meta = metaRaw ? JSON.parse(metaRaw) : null;
  const payloadText = '{"success":true,"fetchedAt":"' + (meta && !forceWrite && meta.fingerprint === fp ? meta.fetchedAt || nowIso : nowIso) + '","table":' + rawTable + "}";
  if (!forceWrite && meta && meta.fingerprint === fp) {
    // نفس الداتا بالظبط زي آخر مرة اتكتبت — صفر كتابات KV (توفير الـ quota).
    return { success: true, fetchedAt: meta.fetchedAt || nowIso, rawResponseText: payloadText, unchanged: true };
  }
  await Promise.all([
    env.SYNC_CACHE.put(CACHE_KEY_CONFIRMED_BY_DAY, payloadText),
    env.SYNC_CACHE.put(CACHE_KEY_CONFIRMED_BY_DAY_META, JSON.stringify({ fingerprint: fp, fetchedAt: nowIso })),
  ]);
  return { success: true, fetchedAt: nowIso, rawResponseText: payloadText };
}

async function handleGetConfirmedByDay(env) {
  try {
    let cachedText = await env.SYNC_CACHE.get(CACHE_KEY_CONFIRMED_BY_DAY);
    if (!cachedText) {
      const fresh = await refreshConfirmedByDayCache(env, true);
      cachedText = fresh.rawResponseText;
    }
    const errorRaw = await env.SYNC_CACHE.get(CACHE_KEY_CONFIRMED_BY_DAY_ERROR);
    // v1.1.48: بنضيف lastError كنص مباشرة جوه الرد الخام (appendJsonField)
    // بدل JSON.parse(cached) + {...payload, lastError} + jsonResponse — ده
    // كان بيحصل مع *كل طلب قراءة* من أي يوزر (مش بس كل 5 دقايق زي الـ cron)،
    // يعني كان أغلى تكلفة CPU فعلية في الملف ده كله.
    const finalText = appendJsonField(cachedText, "lastError", errorRaw || "null");
    return new Response(finalText, { headers: corsHeaders() });
  } catch (err) {
    return jsonResponse({ success: false, message: (err && err.message) || String(err) }, 502);
  }
}

// نفس فكرة refreshConfirmedByDayCache فوق بالظبط (raw text + بصمة + دمج
// كتابات KV) — قبل كده كان بيستخدم fetchGvizSheet (parsed) ويكتب في KV كل
// تشغيلة cron من غير أي مقارنة، وده كان بيساهم في استهلاك الـ 1,000
// كتابة/يوم برضو.
async function refreshIncentiveMerchantsCache(env, forceWrite) {
  const sheetId = env.SHEET_ID;
  if (!sheetId) throw new Error("SHEET_ID env var is not configured in wrangler.toml");
  const rawTable = await fetchGvizSheetRaw(sheetId, INCENTIVE_MERCHANTS_GID);
  const fp = rawTextFingerprint(rawTable);
  const nowIso = new Date().toISOString();
  const metaRaw = await env.SYNC_CACHE.get(CACHE_KEY_INCENTIVE_MERCHANTS_META);
  const meta = metaRaw ? JSON.parse(metaRaw) : null;
  const payloadText = '{"success":true,"fetchedAt":"' + (meta && !forceWrite && meta.fingerprint === fp ? meta.fetchedAt || nowIso : nowIso) + '","table":' + rawTable + "}";
  if (!forceWrite && meta && meta.fingerprint === fp) {
    return { success: true, fetchedAt: meta.fetchedAt || nowIso, rawResponseText: payloadText, unchanged: true };
  }
  await Promise.all([
    env.SYNC_CACHE.put(CACHE_KEY_INCENTIVE_MERCHANTS, payloadText),
    env.SYNC_CACHE.put(CACHE_KEY_INCENTIVE_MERCHANTS_META, JSON.stringify({ fingerprint: fp, fetchedAt: nowIso })),
  ]);
  return { success: true, fetchedAt: nowIso, rawResponseText: payloadText };
}

async function handleGetIncentiveMerchants(env) {
  try {
    let cachedText = await env.SYNC_CACHE.get(CACHE_KEY_INCENTIVE_MERCHANTS);
    if (!cachedText) {
      const fresh = await refreshIncentiveMerchantsCache(env, true);
      cachedText = fresh.rawResponseText;
    }
    const errorRaw = await env.SYNC_CACHE.get(CACHE_KEY_INCENTIVE_MERCHANTS_ERROR);
    const finalText = appendJsonField(cachedText, "lastError", errorRaw || "null");
    return new Response(finalText, { headers: corsHeaders() });
  } catch (err) {
    return jsonResponse({ success: false, message: (err && err.message) || String(err) }, 502);
  }
}

// v1.1.49: بعد إصلاح exceededCpu (v1.1.48)، ظهرت مشكلة تانية مختلفة تمامًا:
// KV عنده حد أقصى لحجم القيمة الواحدة 25MB بالظبط (26,214,400 byte)، وجدول
// Main بقى حجمه كـ نص JSON خام بيتخطى الحد ده (شفناها فعليًا: "KV PUT failed:
// 413 Value length of 27093643 exceeds limit of 26214400"). الحل: نضغط
// (gzip) النص قبل ما نخزنه في KV — Cloudflare Workers فيها CompressionStream
// جاهزة (تنفيذ native سريع جدًا، مش JS عادي، فتكلفتها على CPU budget أقل
// بكتير من فرق حجمها). وبما إن الـ gzip بتاعتنا بتحصل مرة واحدة بس لما
// الشيت "يستقر" (نفس شرط الاستقرار القديم)، مش مع كل طلب قراءة، فالتكلفة
// دي بتتحمل مرة كل تشغيلة ناجحة بس. وكمان بنخدّم النسخة المضغوطة لليوزر
// مباشرة بهيدر Content-Encoding: gzip — المتصفح بيفك الضغط تلقائيًا فمفيش
// أي تكلفة فك ضغط على الـ Worker خالص وقت القراءة.
async function gzipText(text) {
  const bytes = new TextEncoder().encode(text);
  const cs = new CompressionStream("gzip");
  const writer = cs.writable.getWriter();
  writer.write(bytes);
  writer.close();
  return new Response(cs.readable).arrayBuffer();
}

async function refreshMainCache(env, forceWrite) {
  const sheetId = env.SHEET_ID;
  if (!sheetId) throw new Error("SHEET_ID env var is not configured in wrangler.toml");
  // v1.1.48: بنقرا النص الخام بس (من غير JSON.parse) — ده كان السبب
  // الحقيقي المتبقي وراء exceededCpu بعد ما شلنا الـ 21 general-mirror في
  // v1.1.46: JSON.parse لجدول Main (35 ألف صف) لوحده كان بياخد وقت CPU أكتر
  // من الـ ~10ms budget بتاع خطة Cloudflare Free.
  const rawTable = await fetchGvizSheetRaw(sheetId, MAIN_GID);
  const fp = rawTextFingerprint(rawTable);
  const nowIso = new Date().toISOString();
  const rowCount = estimateRowCount(rawTable);

  const candidateRaw = await env.SYNC_CACHE.get(CACHE_KEY_MAIN_CANDIDATE);
  const candidate = candidateRaw ? JSON.parse(candidateRaw) : null;

  // v1.1.51: لو نفس البصمة دي اتكتبت فعلاً قبل كده في CACHE_KEY_MAIN (علامة
  // written:true)، يبقى الداتا لسه زي ما هي من آخر تحديث حقيقي — صفر
  // كتابات KV خالص (راجع الكومنت الكبير فوق refreshConfirmedByDayCache
  // لشرح كامل ليه ده مهم جدًا لخطة Cloudflare Free).
  if (!forceWrite && fp !== null && candidate && candidate.fingerprint === fp && candidate.written) {
    return { success: true, fetchedAt: candidate.fetchedAt || nowIso, stable: true, unchanged: true };
  }

  if (fp !== null && candidate && candidate.fingerprint === fp) {
    // البصمة اتطابقت مع آخر تشغيلة (وده أول مرة تتطابق، لسه ماتكتبتش) —
    // الشيت مستقر، مفيش تعديل شغال عليه دلوقتي. آمن نخدّمه لليوزرز. بنبني
    // نص الرد بـ concatenation مباشرة — من غير JSON.stringify لأي object
    // فيه الجدول الضخم.
    const payloadText = '{"success":true,"fetchedAt":"' + nowIso + '","stable":true,"table":' + rawTable + "}";
    const compressed = await gzipText(payloadText);
    await Promise.all([
      env.SYNC_CACHE.put(CACHE_KEY_MAIN, compressed),
      env.SYNC_CACHE.put(CACHE_KEY_MAIN_META, JSON.stringify({ stable: true, fetchedAt: nowIso, rowCount })),
      env.SYNC_CACHE.put(CACHE_KEY_MAIN_CANDIDATE, JSON.stringify({ fingerprint: fp, fetchedAt: nowIso, rowCount, written: true })),
    ]);
    return { success: true, fetchedAt: nowIso, stable: true, rawResponseText: payloadText };
  }

  // لسه بيتغيّر (أو دي أول تشغيلة خالص) — نسجّل القراءة الخام دي كـ "مرشح"
  // للمرة الجاية بس (written:false)، عشان التشغيلة اللي بعدها تقارن نفسها
  // بيه، من غير أي كتابة لـ CACHE_KEY_MAIN نفسه.
  await env.SYNC_CACHE.put(CACHE_KEY_MAIN_CANDIDATE, JSON.stringify({ fingerprint: fp, fetchedAt: nowIso, rowCount, written: false }));

  const hasExisting = await env.SYNC_CACHE.get(CACHE_KEY_MAIN).then((v) => !!v);
  if (hasExisting) return { success: true, stable: false, skippedReparse: true };

  // مفيش أي نسخة مستقرة اتسجلت قبل كده خالص (أول تشغيلة من عمر الـ Worker) —
  // مضطرين نستخدم القراءة دي زي ما هي عشان الداشبورد مايفضلش فاضي، بس
  // بعلامة stable:false توضح إنها لسه ماتأكدتش.
  const bootstrapText = '{"success":true,"fetchedAt":"' + nowIso + '","stable":false,"table":' + rawTable + "}";
  const compressedBootstrap = await gzipText(bootstrapText);
  await Promise.all([
    env.SYNC_CACHE.put(CACHE_KEY_MAIN, compressedBootstrap),
    env.SYNC_CACHE.put(CACHE_KEY_MAIN_META, JSON.stringify({ stable: false, fetchedAt: nowIso, rowCount })),
  ]);
  return { success: true, fetchedAt: nowIso, stable: false, rawResponseText: bootstrapText };
}

async function handleGetMain(env) {
  try {
    // v1.1.49: الـ KV بقى مخزن فيه bytes مضغوطة (gzip)، مش نص — لازم نقراها
    // كـ arrayBuffer، ونرجعها للمتصفح زي ما هي مع هيدر Content-Encoding:
    // gzip عشان يفك الضغط لوحده تلقائيًا (نفس آلية أي رد HTTP مضغوط عادي).
    let cachedBuf = await env.SYNC_CACHE.get(CACHE_KEY_MAIN, { type: "arrayBuffer" });
    if (!cachedBuf) {
      const fresh = await refreshMainCache(env, true);
      if (fresh && fresh.rawResponseText) {
        return new Response(fresh.rawResponseText, { headers: corsHeaders() });
      }
      return jsonResponse(fresh);
    }
    const headers = corsHeaders();
    headers["Content-Encoding"] = "gzip";
    // v1.1.49 (تصحيح): من غير encodeBody:"manual"، Cloudflare's edge بتحاول
    // كمان تضغط الرد بتاعنا (لأنه Content-Type: application/json و
    // Accept-Encoding: gzip من المتصفح)، فبيحصل ضغط مزدوج — bytes اتضغطت
    // مرتين. المتصفح بيفك مرة واحدة بس (تلقائي حسب هيدر Content-Encoding)
    // ويفضل معاه نص مضغوط لسه (طلعت شكلها بايتس عشوائية مش JSON). ده اللي
    // كان بيحصل فعليًا وشفناه لما فتحنا الرابط مباشرة. الحل: encodeBody:
    // "manual" بيقول لـ Cloudflare "الـ body ده متضغوط بالفعل زي ما الهيدر
    // بيقول، متلمسوش" — پاس-ثرو خام من غير أي تعديل. وبرضو بنضيف
    // "no-transform" لهيدر Cache-Control — من غيرها، بعض نقاط Cloudflare
    // (edge POPs) بتتجاهل encodeBody:"manual" وتعيد ضغط الرد تاني برضو
    // (مشكلة موثقة رسميًا من Cloudflare نفسها).
    headers["Cache-Control"] = "no-store, no-transform";
    return new Response(cachedBuf, { headers, encodeBody: "manual" });
  } catch (err) {
    return jsonResponse({ success: false, message: (err && err.message) || String(err) }, 502);
  }
}

// v1.1.46: بعد ما شلنا الـ General Sync (21 شيت) من الـ Worker خالص (بقت
// على Apps Script بس، راجع الكومنت فوق LAST_SYNC_GIDS/scheduled() تحت)،
// forceRefresh بقى بيحدّث بس التلاتة اللي لسه على الـ Worker: Main +
// Confirmed by Day + Incentive Merchants — التلاتة دول خفيفين بما يكفي إنهم
// يتستنوا مع بعض في نفس الرد من غير أي مشكلة CPU.
//
// بوابة بسيطة بإيميل الـ Manager (نفس فكرة "Worker Sync Status" في الفرونت
// اند). المهم: ده مش bypass لشرط الاستقرار — لسه بيمر بنفس منطق المقارنة
// بين بصمتين متتاليتين جوه refreshMainCache بالظبط، بس بيخلي "المتتاليتين"
// تحصل دلوقتي بدل ما تستنى 5 دقايق.
async function handleForceRefresh(request, env, ctx) {
  const url = new URL(request.url);
  const email = String(url.searchParams.get("email") || "").trim().toLowerCase();
  if (!isOwnerEmail(email)) {
    return jsonResponse({ success: false, message: "Not authorized." }, 403);
  }
  try {
    // v1.3.48: Main/Confirmed by Day بقوا من Metabase — بس Incentive Merchants لسه على الـ Worker.
    const main = {}, confirmedByDay = {};
    const incentiveMerchants = await refreshIncentiveMerchantsCache(env);

    return jsonResponse({
      success: true,
      main: { stable: !!main.stable, fetchedAt: main.fetchedAt || null, skippedReparse: !!main.skippedReparse },
      confirmedByDay: { fetchedAt: confirmedByDay.fetchedAt || null },
      incentiveMerchants: { fetchedAt: incentiveMerchants.fetchedAt || null },
    });
  } catch (err) {
    return jsonResponse({ success: false, message: (err && err.message) || String(err) }, 502);
  }
}

// v1.1.33: نسخة خفيفة جدًا من getMain — من غير الجدول الكامل (اللي ممكن
// يبقى عشرات الـ MB)، بس metadata (stable/fetchedAt/عدد الصفوف/آخر خطأ لو
// فيه). الهدف: تسمح لكل اليوزرز (مش بس الـ Manager) إنهم يعملوا "poll" خفيف
// كل شوية عشان يكتشفوا لما الـ Main تتحدث فعليًا، من غير ما يحمّلوا الجدول
// الضخم كامل كل مرة.
async function handleGetMainMeta(env) {
  try {
    // بنقرا CACHE_KEY_MAIN_META الخفيفة بس (راجع تعليقها فوق) — مفيش أي
    // JSON.parse لجدول ضخم هنا خالص، القراءة دي رخيصة جدًا مهما كان حجم
    // شيت الـ Main.
    const [metaRaw, errorRaw, candidateRaw] = await Promise.all([
      env.SYNC_CACHE.get(CACHE_KEY_MAIN_META),
      env.SYNC_CACHE.get(CACHE_KEY_MAIN_ERROR),
      env.SYNC_CACHE.get(CACHE_KEY_MAIN_CANDIDATE),
    ]);
    const lastError = errorRaw ? JSON.parse(errorRaw) : null;
    // lastAttempt: آخر مرة الـ Worker حاول يقرا الشيت فعلاً، حتى لو لسه
    // ماستقرتش (مطابقتش القراءة اللي قبلها) — عشان توضح إن فيه محاولات
    // شغالة بالفعل، مش إن الـ Worker واقف.
    const candidate = candidateRaw ? JSON.parse(candidateRaw) : null;
    const lastAttempt = candidate ? { fetchedAt: candidate.fetchedAt || null, rowCount: candidate.rowCount === undefined ? null : candidate.rowCount } : null;
    if (!metaRaw) {
      return jsonResponse({ success: true, stable: false, fetchedAt: null, rowCount: null, lastError, lastAttempt });
    }
    const meta = JSON.parse(metaRaw);
    return jsonResponse({ success: true, stable: !!meta.stable, fetchedAt: meta.fetchedAt || null, rowCount: meta.rowCount === undefined ? null : meta.rowCount, lastError, lastAttempt });
  } catch (err) {
    return jsonResponse({ success: false, message: (err && err.message) || String(err) }, 502);
  }
}

function isAllowedEmail(email) {
  const re = new RegExp("^[^\\s@]+@" + ALLOWED_EMAIL_DOMAIN.replace(".", "\\.") + "$", "i");
  return re.test(String(email || "").trim());
}

async function getPresenceMap(env) {
  const raw = await env.SYNC_CACHE.get(CACHE_KEY_PRESENCE);
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (err) {
    return {};
  }
}

function pruneStalePresence(map) {
  const cutoff = Date.now() - PRESENCE_STALE_MS;
  const cleaned = {};
  Object.keys(map).forEach((email) => {
    if (map[email] && map[email].lastSeen >= cutoff) cleaned[email] = map[email];
  });
  return cleaned;
}

// v1.1.40: نقلنا heartbeat/get_online_users هنا بالكامل (بدل ما يعدوا على
// Apps Script) — بيانات "مين أونلاين" مؤقتة بطبيعتها ومحتاجاش تتخزن في
// شيت جوجل خالص، فـ KV هنا كافي وأخف بكتير. نفس المنطق بالظبط اللي كان في
// handleHeartbeat/handleGetOnlineUsers جوه backend/Code.gs (PRESENCE_ONLINE_
// WINDOW_MS/PRESENCE_STALE_MS/PRESENCE_ADMIN_EMAIL).
async function handleHeartbeat(request, env) {
  const url = new URL(request.url);
  const email = String(url.searchParams.get("email") || "").trim().toLowerCase();
  const name = String(url.searchParams.get("name") || "").trim();
  if (!email || !isAllowedEmail(email)) {
    return jsonResponse({ success: false, message: "Not authorized." });
  }
  const map = await getPresenceMap(env);
  map[email] = { name: name || email, lastSeen: Date.now() };
  await env.SYNC_CACHE.put(CACHE_KEY_PRESENCE, JSON.stringify(pruneStalePresence(map)));
  return jsonResponse({ success: true });
}

async function handleGetOnlineUsers(request, env) {
  const url = new URL(request.url);
  const requesterEmail = String(url.searchParams.get("requesterEmail") || "").trim().toLowerCase();
  if (!isOwnerEmail(requesterEmail)) {
    return jsonResponse({ success: false, message: "Not authorized." });
  }
  const map = pruneStalePresence(await getPresenceMap(env));
  const cutoff = Date.now() - PRESENCE_ONLINE_WINDOW_MS;
  const online = [];
  Object.keys(map).forEach((email) => {
    const entry = map[email];
    if (entry.lastSeen >= cutoff) online.push({ email, name: entry.name, lastSeen: entry.lastSeen });
  });
  online.sort((a, b) => b.lastSeen - a.lastSeen);
  return jsonResponse({ success: true, now: Date.now(), users: online });
}


// ===== v1.3.28: Release Upload / Download (GitHub) =====
// الـ GitHub token بيتخزن هنا بس (Worker secret) — مش في كود الداشبورد خالص.
// Worker settings → Variables:
//   GITHUB_TOKEN   (Secret)  fine-grained PAT: Contents = Read and write على الريبو ده بس
//   RELEASE_SECRET (Secret)  كلمة سر بتكتبها وانت بترفع نسخة جديدة
//   GITHUB_REPO    (Text)    owner/repo  (مثال: Dashboard-Performance/performance-dashboard)
//   GITHUB_BRANCH  (Text)    اختياري، الافتراضي main
// الملفات بتتحفظ في الريبو تحت releases/ (كل نسخة + latest.json).
const RELEASE_DIR = "releases";

function ghHeaders(env, extra) {
  return Object.assign({
    Authorization: "Bearer " + env.GITHUB_TOKEN,
    "User-Agent": "performance-dashboard-worker",
    "X-GitHub-Api-Version": "2022-11-28",
  }, extra || {});
}
function ghUrl(env, path) {
  return "https://api.github.com/repos/" + env.GITHUB_REPO + "/contents/" + path.split("/").map(encodeURIComponent).join("/");
}
function ghBranch(env) { return env.GITHUB_BRANCH || "main"; }
function releaseConfigured(env) { return !!(env.GITHUB_TOKEN && env.GITHUB_REPO); }

async function ghGetFile(env, path) {
  return fetch(ghUrl(env, path) + "?ref=" + encodeURIComponent(ghBranch(env)), { headers: ghHeaders(env, { Accept: "application/vnd.github+json" }) });
}
async function ghPutFile(env, path, bytesB64, message) {
  let sha;
  const ex = await ghGetFile(env, path);
  if (ex.ok) { sha = (await ex.json()).sha; }
  const body = { message, content: bytesB64, branch: ghBranch(env) };
  if (sha) body.sha = sha;
  const r = await fetch(ghUrl(env, path), { method: "PUT", headers: ghHeaders(env, { "Content-Type": "application/json" }), body: JSON.stringify(body) });
  if (!r.ok) throw new Error("GitHub " + r.status + ": " + (await r.text()).slice(0, 300));
  return r.json();
}
function bytesToB64(bytes) {
  let bin = ""; const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(bin);
}
async function readLatestMeta(env) {
  const r = await fetch(ghUrl(env, RELEASE_DIR + "/latest.json") + "?ref=" + encodeURIComponent(ghBranch(env)), { headers: ghHeaders(env, { Accept: "application/vnd.github.raw+json" }) });
  if (!r.ok) return null;
  try { return JSON.parse(await r.text()); } catch (_e) { return null; }
}

async function handleReleaseInfo(env) {
  if (!releaseConfigured(env)) return jsonResponse({ success: false, message: "GitHub is not configured on the worker (GITHUB_TOKEN / GITHUB_REPO)." }, 501);
  const meta = await readLatestMeta(env);
  if (!meta) return jsonResponse({ success: true, latest: null });
  return jsonResponse({ success: true, latest: meta });
}

async function handleReleaseDownload(env) {
  if (!releaseConfigured(env)) return jsonResponse({ success: false, message: "GitHub is not configured on the worker." }, 501);
  const meta = await readLatestMeta(env);
  if (!meta || !meta.path) return jsonResponse({ success: false, message: "No release uploaded yet." }, 404);
  const r = await fetch(ghUrl(env, meta.path) + "?ref=" + encodeURIComponent(ghBranch(env)), { headers: ghHeaders(env, { Accept: "application/vnd.github.raw+json" }) });
  if (!r.ok) return jsonResponse({ success: false, message: "GitHub " + r.status }, 502);
  const h = corsHeaders();
  h["Content-Type"] = "application/zip";
  h["Content-Disposition"] = 'attachment; filename="' + meta.filename.replace(/"/g, "") + '"';
  return new Response(r.body, { status: 200, headers: h });
}


// ----- v1.3.29: publish the uploaded zip as the live site (single atomic commit) -----
// الزيب بيتفك جوه الـ Worker، وكل ملفات الموقع بتتكتب في الريبو في commit واحد
// → Vercel (الموصّل بالريبو) بينشر لوحده. backend/ و cloudflare-worker/ و releases/
// مش بيتنشروا كموقع (فيهم أسرار الباك اند) + .vercelignore بيمنع Vercel يقدّمهم.
const SITE_SKIP_PREFIXES = ["backend/", "cloudflare-worker/", "releases/", "__MACOSX/", ".git/"];

async function inflateRaw(u8) {
  const ds = new DecompressionStream("deflate-raw");
  const stream = new Blob([u8]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
async function unzipEntries(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let eocd = -1;
  for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("Bad zip (no central directory).");
  const count = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const dec = new TextDecoder();
  const out = [];
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error("Bad zip entry.");
    const method = dv.getUint16(p + 10, true);
    const csize = dv.getUint32(p + 20, true);
    const nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
    const lho = dv.getUint32(p + 42, true);
    const name = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
    p += 46 + nlen + elen + clen;
    if (name.endsWith("/")) continue;
    const lnlen = dv.getUint16(lho + 26, true), lelen = dv.getUint16(lho + 28, true);
    const start = lho + 30 + lnlen + lelen;
    const raw = u8.subarray(start, start + csize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8) data = await inflateRaw(raw);
    else throw new Error("Unsupported zip compression for " + name);
    out.push({ name, data });
  }
  return out;
}
async function ghApi(env, method, path, body) {
  const r = await fetch("https://api.github.com/repos/" + env.GITHUB_REPO + path, {
    method, headers: ghHeaders(env, { Accept: "application/vnd.github+json", "Content-Type": "application/json" }),
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) throw new Error("GitHub " + method + " " + path.split("?")[0] + " → " + r.status + ": " + (await r.text()).slice(0, 200));
  return r.json();
}
async function publishSiteFromZip(env, zipBytes, version) {
  let files = await unzipEntries(zipBytes);
  files = files.filter((f) => !/(^|\/)\.DS_Store$/.test(f.name));
  if (!files.some((f) => f.name === "index.html")) {
    const first = files.length ? files[0].name.split("/")[0] + "/" : "";
    if (first && files.every((f) => f.name.startsWith(first))) files = files.map((f) => ({ name: f.name.slice(first.length), data: f.data }));
  }
  if (!files.some((f) => f.name === "index.html") || !files.some((f) => f.name === "js/app.js"))
    throw new Error("Zip must contain index.html and js/app.js (site NOT updated).");
  files = files.filter((f) => !SITE_SKIP_PREFIXES.some((pre) => f.name.startsWith(pre)) && !/\.zip$/i.test(f.name));
  const branch = ghBranch(env);
  const ref = await ghApi(env, "GET", "/git/ref/heads/" + encodeURIComponent(branch));
  const parent = ref.object.sha;
  const parentCommit = await ghApi(env, "GET", "/git/commits/" + parent);
  const tree = [];
  for (const f of files) {
    const blob = await ghApi(env, "POST", "/git/blobs", { content: bytesToB64(f.data), encoding: "base64" });
    tree.push({ path: f.name, mode: "100644", type: "blob", sha: blob.sha });
  }
  const ig = await ghApi(env, "POST", "/git/blobs", { content: "releases/\nbackend/\ncloudflare-worker/\n*.zip\n", encoding: "utf-8" });
  tree.push({ path: ".vercelignore", mode: "100644", type: "blob", sha: ig.sha });
  const newTree = await ghApi(env, "POST", "/git/trees", { base_tree: parentCommit.tree.sha, tree });
  const commit = await ghApi(env, "POST", "/git/commits", { message: "Deploy dashboard v" + version + " (via Worker Sync Status upload)", tree: newTree.sha, parents: [parent] });
  await ghApi(env, "PATCH", "/git/refs/heads/" + encodeURIComponent(branch), { sha: commit.sha });
  return { files: files.length, commit: commit.sha.slice(0, 7) };
}

async function handleReleaseUpload(request, env) {
  if (request.method !== "POST") return jsonResponse({ success: false, message: "POST required." }, 405);
  if (!releaseConfigured(env) || !env.RELEASE_SECRET) return jsonResponse({ success: false, message: "Upload is not configured on the worker (GITHUB_TOKEN / GITHUB_REPO / RELEASE_SECRET)." }, 501);
  const url = new URL(request.url);
  const email = String(url.searchParams.get("email") || "").trim().toLowerCase();
  if (!isOwnerEmail(email)) return jsonResponse({ success: false, message: "Not authorized." }, 403);
  if ((request.headers.get("X-Release-Secret") || "") !== env.RELEASE_SECRET) return jsonResponse({ success: false, message: "Wrong upload password." }, 403);
  const rawName = String(url.searchParams.get("filename") || "").trim();
  if (!/\.zip$/i.test(rawName)) return jsonResponse({ success: false, message: "Only .zip files are accepted." }, 400);
  const vm = rawName.match(/v?(\d+\.\d+\.\d+)/i);
  const version = vm ? vm[1] : "unknown";
  const bytes = new Uint8Array(await request.arrayBuffer());
  if (!bytes.length || bytes.length > 25 * 1024 * 1024) return jsonResponse({ success: false, message: "Empty or too large (max 25MB)." }, 400);
  if (!(bytes[0] === 0x50 && bytes[1] === 0x4b)) return jsonResponse({ success: false, message: "Not a valid zip file." }, 400);
  const filename = "Performance dashboard v" + version + ".zip";
  const path = RELEASE_DIR + "/" + filename;
  try {
    await ghPutFile(env, path, bytesToB64(bytes), "Upload dashboard v" + version + " (via Worker Sync Status)");
    const meta = { version, filename, path, size: bytes.length, uploadedAt: new Date().toISOString(), uploadedBy: email };
    await ghPutFile(env, RELEASE_DIR + "/latest.json", btoa(JSON.stringify(meta, null, 2)), "Set latest release to v" + version);
    let published = null, publishError = null;
    try { published = await publishSiteFromZip(env, bytes, version); }
    catch (e) { publishError = (e && e.message) || String(e); }
    return jsonResponse({ success: true, latest: meta, published, publishError });
  } catch (err) {
    return jsonResponse({ success: false, message: (err && err.message) || String(err) }, 502);
  }
}

export default {
  async fetch(request, env, ctx) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders() });
    }

    const url = new URL(request.url);
    const action = url.searchParams.get("action");

    if (action === "metabase") return handleMetabaseProxy(url);
    if (action === "getConfirmedByDay") return handleGetConfirmedByDay(env);
    if (action === "getIncentiveMerchants") return handleGetIncentiveMerchants(env);
    if (action === "getMain") return handleGetMain(env);
    if (action === "getMainMeta") return handleGetMainMeta(env);
    if (action === "forceRefresh") return handleForceRefresh(request, env, ctx);
    if (action === "heartbeat") return handleHeartbeat(request, env);
    if (action === "releaseInfo") return handleReleaseInfo(env);
    if (action === "releaseDownload") return handleReleaseDownload(env);
    if (action === "releaseUpload") return handleReleaseUpload(request, env);
    if (action === "getOnlineUsers") return handleGetOnlineUsers(request, env);

    return jsonResponse(
      {
        success: false,
        message:
          "Unknown action. This worker only serves getConfirmedByDay/getIncentiveMerchants/getMain/getMainMeta/forceRefresh/heartbeat/getOnlineUsers — the general sheet sync (getLastSync/getLastSyncMeta) now goes directly to Apps Script, and every other action (login, backup, computed publish) still goes directly to Apps Script too.",
      },
      400
    );
  },

  // Cron Trigger (كل 5 دقايق — راجع wrangler.toml) — بيسحب نسخة جديدة من
  // الشيتات اللي لسه على الـ Worker (Main/Confirmed by Day/Incentive
  // Merchants بس، v1.1.46) ويخزّنها، من غير أي يوزر مستني الرد ده. لو فشلت
  // المحاولة دي، آخر نسخة كانت متخزنة تفضل زي ما هي وتتخدم لليوزرز عادي لحد
  // المحاولة الناجحة اللي بعدها.
  async scheduled(event, env, ctx) {
    ctx.waitUntil(
      Promise.all([
        // v1.3.48: Confirmed by Day اتنقل لـ Metabase — مفيش refresh من Google Sheets.
        refreshIncentiveMerchantsCache(env).then(
          () => env.SYNC_CACHE.delete(CACHE_KEY_INCENTIVE_MERCHANTS_ERROR).catch(() => {}),
          (err) => {
            console.error("[scheduled refresh incentiveMerchants] failed (will retry next cron tick):", err && err.message);
            return env.SYNC_CACHE.put(
              CACHE_KEY_INCENTIVE_MERCHANTS_ERROR,
              JSON.stringify({ message: (err && err.message) || String(err), at: new Date().toISOString() })
            ).catch(() => {});
          }
        ),
        // v1.3.48: Main اتنقل لـ Metabase (CSV) — مفيش refresh من Google Sheets.
      ])
    );
  },
};
