// v1.18.0 — Orders per Hour: one snapshot of Merchant Only's Placed Orders at the top of every Cairo hour (Worker cron).
process.env.TZ = "UTC";
const RealDate = Date; let NOW = RealDate.parse("2026-11-16T07:59:30Z"); // 09:59:30 Cairo (UTC+2 in November)
globalThis.Date = class extends RealDate { constructor(...a) { super(...(a.length ? a : [NOW])); } static now() { return NOW; } };
const worker = (await import("../worker.js")).default;
let pass = 0, fail = 0; const ok = (c, n) => { c ? pass++ : fail++; console.log((c ? "  ✓ " : "  ✗ ") + n); };
const m = new Map();
const KV = { async get(k, o) { const v = m.get(k); if (v == null) return null; if (o && o.type === "arrayBuffer") return v instanceof ArrayBuffer ? v : new TextEncoder().encode(v).buffer; return typeof v === "string" ? v : new TextDecoder().decode(v); },
  async put(k, v) { m.set(k, v); }, async delete(k) { m.delete(k); }, async list() { return { keys: [], list_complete: true }; } };
const env = { SYNC_CACHE: KV, DECLINE_DIGEST: "off", PLANNER_DOH_EXPORT: "off", SUPPLY_CONVERSION_EXPORT: "off", INV_CATEGORY_EXPORT: "off" };
let answer = null, fetches = 0;
globalThis.fetch = async (u) => { u = String(u); if (u.indexOf("metabase.taager.com") > -1) { fetches++; if (answer instanceof Error) throw answer; return new Response(answer.body, { status: answer.status || 200, headers: { "Content-Type": "text/csv" } }); } throw new Error("other source offline in this test"); };
const csv = (rows) => "DAY,COUNTRY,TAGER_ID,TAGER_NAME,ACC_MANAGER,PLACED_ORDERS,CONFIRMED,DELIVERED,TOTAL_GMV\n" + rows.map((r) => r.join(",")).join("\n") + "\n";
const tick = async () => { const w = []; await worker.scheduled({}, env, { waitUntil: (p) => w.push(p) }); await Promise.all(w); };
const api = async () => (await worker.fetch(new Request("https://w/?action=hourlyOrders"), env, {})).json();
const snaps = async () => (await api()).snapshots;

// Merchant Only at 10:00: yesterday 4,000 / today 1,000+2,000 (EGY) ; a SAU merchant is left out ; 1160154 (tagged SAU) is Egypt
answer = { body: csv([["2026-11-15", "EGY", "1", "A", "x", 1500, 0, 0, 0], ["2026-11-15", "EGY", "2", "B", "x", 2500, 0, 0, 0],
  ["2026-11-16", "EGY", "1", "A", "x", 1000, 0, 0, 0], ["2026-11-16", "EGY", "2", "B", '"x, y"', 2000, 0, 0, 0], ["2026-11-16", "SAU", "9", "Z", "x", 777, 0, 0, 0], ["2026-11-16", "SAU", "1160154", "adm", "x", 50, 0, 0, 0]]) };
await tick();
ok((await snaps()).length === 0, "09:59:30 Cairo → no point (not the start of an hour)");
NOW = RealDate.parse("2026-11-16T08:00:00Z"); await tick(); // 10:00 Cairo
let s = await snaps();
ok(s.length === 1 && s[0].hour === 10 && s[0].cairoDate === "2026-11-16", "10:00 Cairo → one point for hour 10");
ok(s[0].dataDay === "2026-11-16" && s[0].placed === 3050, "placed = today's Placed Orders, Egypt only (EGY 3,000 + merchant 1160154 = 50; the SAU merchant is left out)");
ok(s[0].days["2026-11-15"] === 4000, "yesterday's total travels with the point (4,000)");
NOW += 60e3; await tick(); NOW += 120e3; await tick();
ok((await snaps()).length === 1, "10:01 / 10:03 → still one point for the hour (no duplicates)");
NOW = RealDate.parse("2026-11-16T08:20:00Z"); await tick(); ok((await snaps()).length === 1, "10:20 → nothing (only the first minutes of an hour are used)");

// 11:00 — Metabase is down: nothing is stored, and the saved "last good copy" is NOT used as an on-the-hour number
answer = new Error("network"); NOW = RealDate.parse("2026-11-16T09:00:00Z"); await tick();
ok((await snaps()).length === 1, "11:00 Metabase down → no point (never the old saved copy)");
let st = (await api()).status; ok(st && st.ok === false && /live answer/.test(st.why), "status says why: no live answer");
answer = { body: csv([["2026-11-15", "EGY", "1", "A", "x", 1500, 0, 0, 0], ["2026-11-15", "EGY", "2", "B", "x", 2500, 0, 0, 0], ["2026-11-16", "EGY", "1", "A", "x", 1300, 0, 0, 0], ["2026-11-16", "EGY", "2", "B", "x", 2400, 0, 0, 0], ["2026-11-16", "SAU", "9", "Z", "x", 800, 0, 0, 0], ["2026-11-16", "SAU", "1160154", "adm", "x", 70, 0, 0, 0]]) };
NOW = RealDate.parse("2026-11-16T09:02:00Z"); await tick();
s = await snaps(); ok(s.length === 2 && s[1].hour === 11 && s[1].placed === 3770, "11:02 Metabase back → the hour-11 point is taken then (3,770)");
ok(new RealDate(s[1].at).toISOString() === "2026-11-16T09:02:00.000Z", "the point keeps the real time it was taken");

// 12:00 — the answer is not a Merchant Only answer (columns changed)
answer = { body: "A,B\n1,2\n" }; NOW = RealDate.parse("2026-11-16T10:00:00Z"); await tick();
ok((await snaps()).length === 2, "12:00 wrong columns → no point");
// next day: the Cairo date rolls at midnight, the 00:00 point belongs to the new date
answer = { body: csv([["2026-11-15", "EGY", "1", "A", "x", 1500, 0, 0, 0], ["2026-11-15", "EGY", "2", "B", "x", 2500, 0, 0, 0], ["2026-11-16", "EGY", "1", "A", "x", 5000, 0, 0, 0], ["2026-11-16", "EGY", "2", "B", "x", 100, 0, 0, 0], ["2026-11-17", "EGY", "1", "A", "x", 9, 0, 0, 0], ["2026-11-17", "SAU", "7", "Q", "x", 1, 0, 0, 0]]) };
NOW = RealDate.parse("2026-11-16T22:00:00Z"); await tick(); // 00:00 Cairo on the 17th
s = await snaps(); const last = s[s.length - 1];
ok(last.cairoDate === "2026-11-17" && last.hour === 0 && last.dataDay === "2026-11-17" && last.placed === 9, "00:00 Cairo → date 17th, hour 0, today = the 17th");
// the same CSV with DAY still on the 16th at 00:00 (a UTC-based DAY) keeps its own dataDay
answer = { body: csv([["2026-11-14", "EGY", "1", "A", "x", 1, 0, 0, 0], ["2026-11-15", "EGY", "1", "A", "x", 1500, 0, 0, 0], ["2026-11-15", "EGY", "2", "B", "x", 2500, 0, 0, 0], ["2026-11-16", "EGY", "1", "A", "x", 5200, 0, 0, 0], ["2026-11-16", "EGY", "2", "B", "x", 100, 0, 0, 0], ["2026-11-16", "SAU", "7", "Q", "x", 1, 0, 0, 0]]) }; NOW = RealDate.parse("2026-11-17T22:00:00Z"); await tick();
s = await snaps(); ok(s[s.length - 1].dataDay === "2026-11-16" && s[s.length - 1].cairoDate === "2026-11-18", "dataDay is stored separately from the Cairo clock (no assumption about the day boundary)");
ok(m.get("hourly:lock") == null, "no lock left behind");
ok((await api()).success === true, "endpoint answers");
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
