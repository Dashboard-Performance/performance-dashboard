// v1.18.3 — Orders per Hour: the Worker looks every 10 minutes and stores a point only when Metabase's number changed (at that minute).
// With METABASE_API_KEY it runs the card forced (ignore_cache), without it it reads the public link.
process.env.TZ = "UTC";
const RealDate = Date; let NOW = RealDate.parse("2026-11-17T10:00:20Z"); // 12:00 Cairo
globalThis.Date = class extends RealDate { constructor(...a) { super(...(a.length ? a : [NOW])); } static now() { return NOW; } };
const worker = (await import(process.argv[2] || "../worker.js")).default;
let pass = 0, fail = 0; const ok = (c, n) => { c ? pass++ : fail++; console.log((c ? "  ✓ " : "  ✗ ") + n); };
const m = new Map();
const KV = { async get(k, o) { const v = m.get(k); if (v == null) return null; if (o && o.type === "arrayBuffer") return v instanceof ArrayBuffer ? v : new TextEncoder().encode(v).buffer; return typeof v === "string" ? v : new TextDecoder().decode(v); },
  async put(k, v) { m.set(k, v); }, async delete(k) { m.delete(k); }, async list() { return { keys: [], list_complete: true }; } };
const base = { SYNC_CACHE: KV, DECLINE_DIGEST: "off", PLANNER_DOH_EXPORT: "off", SUPPLY_CONVERSION_EXPORT: "off", INV_CATEGORY_EXPORT: "off" };
let pub = 1027, fresh = 1027, calls = { pub: 0, forced: 0 }, forcedBody = null, forcedKey = null;
const csv = (today) => "DAY,COUNTRY,TAGER_ID,TAGER_NAME,PLACED_ORDERS\n2026-11-17,EGY,1,a," + (today - 27) + "\n2026-11-17,EGY,2,b,27\n2026-11-16,EGY,1,a,4623\n2026-11-17,KWT,9,k,500\n";
const json = (today) => ({ status: "completed", data: { cols: ["DAY", "COUNTRY", "TAGER_ID", "TAGER_NAME", "PLACED_ORDERS"].map((name) => ({ name })),
  rows: [["2026-11-17T00:00:00Z", "EGY", "1", "a", today - 27], ["2026-11-17T00:00:00Z", "EGY", "2", "b", 27], ["2026-11-16T00:00:00Z", "EGY", "1", "a", 4623], ["2026-11-17T00:00:00Z", "KWT", "9", "k", 500]] } });
globalThis.fetch = async (u, o) => {
  u = String(u);
  if (u.indexOf("/api/card/4575/query") > -1) { calls.forced++; forcedBody = o && o.body; forcedKey = o && o.headers && o.headers["x-api-key"]; return new Response(JSON.stringify(json(fresh)), { status: 200 }); }
  if (u.indexOf("metabase.taager.com") > -1 && /\/csv|\.csv/.test(u)) { calls.pub++; return new Response(csv(pub), { status: 200, headers: { "Content-Type": "text/csv" } }); }
  if (u.indexOf("metabase.taager.com") > -1) { calls.pub++; return new Response(JSON.stringify(json(pub)), { status: 200 }); }
  throw new Error("other source offline in this test");
};
const tick = async (iso, env) => { NOW = RealDate.parse(iso); const w = []; await worker.scheduled({}, env, { waitUntil: (p) => w.push(p) }); await Promise.all(w); };
const snaps = () => JSON.parse(m.get("hourly:snap:2026-11-17") || "[]");

console.log("without an API key (public link, Metabase refreshes on its own clock)");
await tick("2026-11-17T10:00:20Z", base);
ok(snaps().length === 1 && snaps()[0].placed === 1027 && snaps()[0].minute === 0, "12:00 first look stores 1,027 at 12:00");
await tick("2026-11-17T10:05:20Z", base);
ok(snaps().length === 1, "12:05 is not a look minute (every 10 min)");
await tick("2026-11-17T10:10:20Z", base); await tick("2026-11-17T11:00:20Z", base); await tick("2026-11-17T12:00:20Z", base);
ok(snaps().length === 1, "12:10 / 13:00 / 14:00 Metabase still says 1,027 -> no new point (no flat repeats)");
pub = 1622;
await tick("2026-11-17T12:30:20Z", base);
ok(snaps().length === 2 && snaps()[1].placed === 1622 && snaps()[1].hour === 14 && snaps()[1].minute === 30, "14:30 Metabase refreshed -> a point at 14:30 with 1,622");
ok(snaps()[1].days["2026-11-16"] === 4623 && snaps()[1].read === "public", "the point carries yesterday's total and how it was read");
ok(calls.forced === 0, "no forced run without a key");
const st = JSON.parse(m.get("hourly:status")); ok(st.ok && st.changed === true && st.minute === 30, "status says when it last looked and that it changed");
await tick("2026-11-17T12:40:20Z", base);
ok(JSON.parse(m.get("hourly:status")).changed === false && snaps().length === 2, "14:40 no change -> status updated, no point");

console.log("with METABASE_API_KEY (forced run = pressing Refresh)");
const env = Object.assign({}, base, { METABASE_API_KEY: "test-key" });
fresh = 1800;
await tick("2026-11-17T12:50:20Z", env);
ok(calls.forced === 1 && forcedKey === "test-key" && JSON.parse(forcedBody).ignore_cache === true, "the card is run signed in with ignore_cache");
ok(snaps().length === 3 && snaps()[2].placed === 1800 && snaps()[2].read === "forced", "14:50 forced run gives 1,800 although the public link still says 1,622");
await tick("2026-11-17T13:00:20Z", env);
ok(calls.forced === 2, "every look is a new forced run (reuse window for the cron is 1 minute)");
ok(snaps().length === 3, "same number -> no new point");
// the Daily Orders proxy reuses the forced answer for 5 minutes (it polls every minute)
const r = await worker.fetch(new Request("https://w.example/?action=metabase&gid=7100000001&maxage=60"), env, { waitUntil() {} }).catch((e) => ({ status: "err " + e.message }));
ok(calls.forced === 2, "a Daily Orders read right after reuses the forced answer (no extra Snowflake run)" + (r && r.status ? " [status " + r.status + "]" : ""));
console.log("\n" + pass + " passed, " + fail + " failed"); if (fail) process.exit(1);
